import "dotenv/config";
import express from "express";
import cors from "cors";
import { v4 as uuid } from "uuid";
import { fetchTonTransactions, extractComment, extractTonAmountNano, normalizeAddr } from "./ton.js";

const fs = require("fs");
const path = require("path");

const app = express();
app.use(express.json());
app.use(cors({ origin: process.env.CORS_ORIGIN || "*", credentials: false }));

// In-memory store (prototype). Swap to DB later.
const deposits = new Map(); // id -> {id, currency, usd, expectedNano, status, createdAt, confirmedAt, txHash}
const withdrawals = new Map(); // id -> {id,userId,address,currency,usd,feePct,netUsd,requestedAt,processAfter,status,paidAt,txHash}

// Server-side ledger (prototype)
const split = { treasury: 0.60, profit: 0.30, buffer: 0.10 };
function loadDb(){
  try{
    if(!fs.existsSync(DB_FILE)) return null;
    const raw = fs.readFileSync(DB_FILE, "utf-8");
    return JSON.parse(raw);
  }catch(e){ return null; }
}

let saveTimer = null;
function scheduleSave(){
  if(saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try{
      const data = {
        ledger,
        deposits: Array.from(deposits.entries()),
        withdrawals: Array.from(withdrawals.entries())
      };
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
    }catch(e){}
  }, 250);
}

let ledger = { treasuryUsd: 0, profitUsd: 0, bufferUsd: 0, withdrawalsPaused: false, withdrawFeePct: 0.05, withdrawDelayMs: 24*60*60*1000, withdrawDailyCapUsd: 10, withdrawWeeklyCapUsd: 50, paidTodayUsd: 0, paidWeekUsd: 0, lastDayKey: null, lastWeekKey: null };

const loaded = loadDb();
if (loaded) {
  try {
    if (loaded.ledger) ledger = { ...ledger, ...loaded.ledger };
    if (Array.isArray(loaded.deposits)) {
      deposits.clear();
      for (const [k,v] of loaded.deposits) deposits.set(k,v);
    }
    if (Array.isArray(loaded.withdrawals)) {
      withdrawals.clear();
      for (const [k,v] of loaded.withdrawals) withdrawals.set(k,v);
    }
  } catch(e) {}
}



function dayKey(ts=Date.now()){
  const d=new Date(ts);
  return `${d.getUTCFullYear()}-${d.getUTCMonth()+1}-${d.getUTCDate()}`;
}
function weekKey(ts=Date.now()){
  const d=new Date(ts);
  const day=(d.getUTCDay()+6)%7;
  const monday=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()-day));
  return `${monday.getUTCFullYear()}-${monday.getUTCMonth()+1}-${monday.getUTCDate()}`;
}
function deepFindString(obj, needle){
  try{
    if(obj == null) return null;
    if(typeof obj === "string"){
      return obj.includes(needle) ? obj : null;
    }
    if(typeof obj !== "object") return null;
    if(Array.isArray(obj)){
      for(const it of obj){
        const r = deepFindString(it, needle);
        if(r) return r;
      }
      return null;
    }
    for(const k of Object.keys(obj)){
      const r = deepFindString(obj[k], needle);
      if(r) return r;
    }
    return null;
  }catch{ return null; }
}

function deepPick(obj, keys){
  // find first value for any key in keys in object tree
  try{
    if(obj == null) return null;
    if(typeof obj !== "object") return null;
    if(Array.isArray(obj)){
      for(const it of obj){
        const r = deepPick(it, keys);
        if(r != null) return r;
      }
      return null;
    }
    for(const k of Object.keys(obj)){
      if(keys.includes(k)) return obj[k];
      const r = deepPick(obj[k], keys);
      if(r != null) return r;
    }
    return null;
  }catch{ return null; }
}

function resetCapsIfNeeded(now=Date.now()){
  const dk=dayKey(now);
  const wk=weekKey(now);
  if(ledger.lastDayKey!==dk){ ledger.paidTodayUsd=0; ledger.lastDayKey=dk; }
  if(ledger.lastWeekKey!==wk){ ledger.paidWeekUsd=0; ledger.lastWeekKey=wk; }
}


const DB_FILE = process.env.DB_FILE || path.join(process.cwd(), "tonzoo_db.json");

const TREASURY = normalizeAddr(process.env.TREASURY_ADDRESS || "");

function usdToNanoTon(usd){
  // Prototype conversion for verification:
  // Provide a fixed TON/USD in your front-end when generating expected ton.
  // Here we accept "any >= expected" if expectedNano provided by client.
  return 0;
}

app.get("/api/health", (req,res)=>res.json({ ok:true, treasury:TREASURY }));

app.post("/api/deposits/create", (req,res)=>{
  const { currency="TON", usd=1, expectedNano=0 } = req.body || {};
  const id = "dep_" + uuid().slice(0,8);
  const d = {
    id,
    currency,
    usd: Number(usd)||1,
    expectedNano: Number(expectedNano)||0,
    status: "Pending",
    createdAt: Date.now()
  };
  deposits.set(id, d);
  scheduleSave();
  res.json({
    deposit: d,
    pay: {
      address: TREASURY,
      comment: `TONZOO:${id}`,
      expectedNano: d.expectedNano
    }
  });
});

// Poll chain and confirm matching deposits
app.post("/api/demo/confirm", (req,res)=>{
  // Demo-only shortcut: instantly confirm a deposit intent by id (no chain)
  const id = (req.body?.id || "").trim();
  const dep = deposits.get(id);
  if (!dep) return res.status(404).json({ ok:false, error:"Unknown deposit id" });
  if (dep.status === "Confirmed") return scheduleSave();
  res.json({ ok:true, confirmed:[dep], ledger });

  dep.status = "Confirmed";
  dep.confirmedAt = Date.now();
  dep.txHash = "DEMO_TX_" + uuid().slice(0,10);

  // split + ledger
  const tAdd = dep.usd * split.treasury;
  const pAdd = dep.usd * split.profit;
  const bAdd = dep.usd * split.buffer;
  dep.split = { tAdd, pAdd, bAdd, coinsAdd: Math.floor(dep.usd * 1000) };

  ledger.treasuryUsd = +(ledger.treasuryUsd + tAdd).toFixed(2);
  ledger.profitUsd = +(ledger.profitUsd + pAdd).toFixed(2);
  ledger.bufferUsd = +(ledger.bufferUsd + bAdd).toFixed(2);

  deposits.set(id, dep);
  scheduleSave();
  resetCapsIfNeeded(Date.now());
  res.json({ ok:true, confirmed:[dep], ledger });
});

app.get("/api/jetton/wallet_address", async (req,res)=>{
  const owner = String(req.query.owner||"").trim();
  const master = String(req.query.master||process.env.USDT_JETTON_MASTER||"").trim();
  if(!owner || !master) return res.status(400).json({ ok:false, error:"owner/master required" });

  try{
    const ownerAddr = Address.parse(owner);
    const masterAddr = master;
    // stack expects slice containing owner address
    const sliceCell = beginCell().storeAddress(ownerAddr).endCell();
    const sliceB64 = sliceCell.toBoc().toString("base64");

    const tcKey = process.env.TONCENTER_KEY || process.env.TONCENTER_API_KEY || "";
    const urlBase = process.env.TONCENTER_URL || "https://toncenter.com/api/v2";
    const url = urlBase.replace(/\/$/,"") + "/runGetMethod" + (tcKey ? ("?api_key=" + encodeURIComponent(tcKey)) : "");
    const r = await fetch(url, {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ address: masterAddr, method: "get_wallet_address", stack: [["slice", sliceB64]] })
    });
    const j = await r.json();

    // toncenter returns {ok:true,result:{stack:...}} in some variants; handle both
    const stack = j?.result?.stack || j?.stack || j?.result || null;
    let addrB64 = null;
    if(Array.isArray(stack) && stack.length){
      // common format: [ ["slice", "BASE64..."], ... ]
      if(Array.isArray(stack[0]) && typeof stack[0][1] === "string") addrB64 = stack[0][1];
      // v3-like object
      if(stack[0]?.value) addrB64 = stack[0].value;
    }
    if(!addrB64) return res.status(500).json({ ok:false, error:"Could not parse runGetMethod response", raw:j });

    const outCell = beginCell().endCell(); // dummy
    // Parse address from returned slice cell
    const boc = Buffer.from(addrB64, "base64");
    const { Cell } = require("@ton/core");
    const [cell] = Cell.fromBoc(boc);
    const s = cell.beginParse();
    const outAddr = s.loadAddress();

    res.json({ ok:true, jettonWallet: outAddr.toString({ urlSafe: true, bounceable: true }) });
  }catch(e){
    console.error(e);
    res.status(500).json({ ok:false, error: String(e?.message||e) });
  }
});

async function checkUsdtDepositsTonApi(treasuryAddr, jettonMaster, depositId){
  const apiKey = process.env.TONAPI_KEY || "";
  if(!apiKey) return null;
  // TONAPI endpoint per docs: /v2/accounts/{account_id}/jettons/{jetton_id}/history
  const base = process.env.TONAPI_URL || "https://tonapi.io";
  const url = base.replace(/\/$/,"") + `/v2/accounts/${encodeURIComponent(treasuryAddr)}/jettons/${encodeURIComponent(jettonMaster)}/history?limit=50`;
  const r = await fetch(url, { headers: { "Authorization": `Bearer ${apiKey}` } });
  const j = await r.json();
  const needle = `TONZOO:${depositId}`;
  const items = j?.events || j?.items || j?.history || j?.transfers || [];
  for(const it of items){
    const hit = deepFindString(it, needle);
    if(!hit) continue;
    // try get tx hash and amount
    const txHash = deepPick(it, ["hash","tx_hash","transaction_hash","txHash","event_id","id"]);
    const amount = deepPick(it, ["amount","jetton_amount","quantity","value"]);
    return { txHash, amount, raw: it };
  }
  return null;
}

async function scanDeposits(limit){
  const found = [];
  const lim = limit;
const limit = Math.min(100, Math.max(10, Number(req.body?.limit)||40));
    const txs = await fetchTonTransactions(process.env, TREASURY, limit);

    // build index: comment -> tx
    const found = [];
    for(const tx of txs){
      const c = extractComment(tx.inMsg);
      if(!c) continue;
      if(!c.startsWith("TONZOO:")) continue;
      const id = c.trim().split("TONZOO:")[1]?.trim();
      if(!id) continue;
      const dep = deposits.get(id);
      if(!dep) continue;
      if(dep.status === "Confirmed") continue;

      // naive verification for prototype:
      // - currency TON: confirm any inbound >= expectedNano (if provided) OR any inbound if expectedNano=0
      const nano = extractTonAmountNano(tx.inMsg);
      if(dep.currency === "TON"){
        if(dep.expectedNano > 0 && nano < dep.expectedNano) continue;
        dep.status = "Confirmed";
        dep.confirmedAt = Date.now();
        dep.txHash = tx.id;
        dep.receivedNano = nano;
         // split + ledger
 const tAdd = dep.usd * split.treasury;
 const pAdd = dep.usd * split.profit;
 const bAdd = dep.usd * split.buffer;
 dep.split = { tAdd, pAdd, bAdd, coinsAdd: Math.floor(dep.usd * 1000) };
 ledger.treasuryUsd = +(ledger.treasuryUsd + tAdd).toFixed(2);
 ledger.profitUsd = +(ledger.profitUsd + pAdd).toFixed(2);
 ledger.bufferUsd = +(ledger.bufferUsd + bAdd).toFixed(2);
 found.push(dep);
      } else {
        // USDT on TON requires parsing jetton transfers. For prototype we still match comment in inbound message.
        // In Phase C we will parse jetton transfer payload properly.
        dep.status = "Confirmed";
        dep.confirmedAt = Date.now();
        dep.txHash = tx.id;
         // split + ledger
 const tAdd = dep.usd * split.treasury;
 const pAdd = dep.usd * split.profit;
 const bAdd = dep.usd * split.buffer;
 dep.split = { tAdd, pAdd, bAdd, coinsAdd: Math.floor(dep.usd * 1000) };
 ledger.treasuryUsd = +(ledger.treasuryUsd + tAdd).toFixed(2);
 ledger.profitUsd = +(ledger.profitUsd + pAdd).toFixed(2);
 ledger.bufferUsd = +(ledger.bufferUsd + bAdd).toFixed(2);
 found.push(dep);
      }

      deposits.set(id, dep);
    }

    resetCapsIfNeeded(Date.now());
    res.json({ ok:true, confirmed: found, total: deposits.size, ledger });
  return { found, ledger, total: deposits.size };
}

app.post("/api/deposits/check", async (req,res)=>{
  try{
    const limit = Math.min(100, Math.max(10, Number(req.body?.limit)||40));
    const r = await scanDeposits(limit);
    res.json({ ok:true, confirmed: r.found, total: r.total, ledger: r.ledger });
  }catch(e){
    res.status(500).json({ ok:false, error: e.message });
  }
});

app.get("/api/deposits/:id", (req,res)=>{
  const dep = deposits.get(req.params.id);
  if(!dep) return res.status(404).json({ ok:false });
  res.json({ ok:true, deposit: dep });
});

app.get("/api/admin/status", (req,res)=>{
  resetCapsIfNeeded(Date.now());
  res.json({ ok:true, ledger, totals: { deposits: deposits.size, withdrawals: withdrawals.size } });
});

app.post("/api/admin/config", (req,res)=>{
  const b = req.body || {};
  if (typeof b.withdrawalsPaused === "boolean") ledger.withdrawalsPaused = b.withdrawalsPaused;
  if (typeof b.withdrawFeePct === "number") ledger.withdrawFeePct = Math.max(0, Math.min(0.2, b.withdrawFeePct));
  if (typeof b.withdrawDelayMs === "number") ledger.withdrawDelayMs = Math.max(0, b.withdrawDelayMs);
  if (typeof b.withdrawDailyCapUsd === "number") ledger.withdrawDailyCapUsd = Math.max(0, b.withdrawDailyCapUsd);
  if (typeof b.withdrawWeeklyCapUsd === "number") ledger.withdrawWeeklyCapUsd = Math.max(0, b.withdrawWeeklyCapUsd);
  resetCapsIfNeeded(Date.now());
  scheduleSave();
  res.json({ ok:true, ledger });
});

app.post("/api/withdrawals/request", (req,res)=>{
  resetCapsIfNeeded(Date.now());
  const { userId="local", address="", currency="TON", usd=1 } = req.body || {};
  const u = Math.max(0.01, Number(usd)||1);
  const feePct = ledger.withdrawFeePct;
  const net = Math.max(0, +(u * (1-feePct)).toFixed(2));
  const id = "wd_" + uuid().slice(0,10);
  const w = { id, userId, address, currency, usd: +u.toFixed(2), feePct, netUsd: net, requestedAt: Date.now(), processAfter: Date.now() + ledger.withdrawDelayMs, status: "Pending" };
  withdrawals.set(id, w);
  scheduleSave();
  res.json({ ok:true, withdrawal: w, ledger });
});

app.get("/api/withdrawals/list", (req,res)=>{
  resetCapsIfNeeded(Date.now());
  const list = Array.from(withdrawals.values()).sort((a,b)=>(b.requestedAt||0)-(a.requestedAt||0)).slice(0,50);
  res.json({ ok:true, withdrawals: list, ledger });
});

app.post("/api/withdrawals/process", async (req,res)=>{
  resetCapsIfNeeded(Date.now());
  const now = Date.now();
  const paid = [];
  for (const w of withdrawals.values()){
    if (w.status !== "Pending") continue;
    if ((w.processAfter||0) > now) continue;
    if (ledger.withdrawalsPaused){ w.status = "Paused"; continue; }
    if (ledger.treasuryUsd < w.netUsd){ w.status = "Insufficient treasury"; continue; }
    if (ledger.paidTodayUsd + w.netUsd > ledger.withdrawDailyCapUsd){ w.status = "Daily cap reached"; continue; }
    if (ledger.paidWeekUsd + w.netUsd > ledger.withdrawWeeklyCapUsd){ w.status = "Weekly cap reached"; continue; }

    // Prototype payout: mark as paid + deduct treasury (real chain send in Phase C2)
    ledger.treasuryUsd = +(ledger.treasuryUsd - w.netUsd).toFixed(2);
    ledger.paidTodayUsd = +(ledger.paidTodayUsd + w.netUsd).toFixed(2);
    ledger.paidWeekUsd = +(ledger.paidWeekUsd + w.netUsd).toFixed(2);

    w.status = "Paid";
    w.paidAt = now;
    w.txHash = "SIM_TX_" + uuid().slice(0,12);
    paid.push(w);
  }
  scheduleSave();
  res.json({ ok:true, paid, ledger });
});

const PORT = Number(process.env.PORT)||8787;
app.listen(PORT, ()=>console.log(`[tonzoo-server] listening on :${PORT}`));

const POLL_MS = Math.max(0, Number(process.env.POLL_INTERVAL_MS || 0));
if (POLL_MS > 0) {
  console.log(`[tonzoo-server] deposit poller enabled: ${POLL_MS}ms`);
  setInterval(async () => {
    try {
      // scan small window frequently
      await scanDeposits(50);
    } catch (e) {
      // keep quiet to avoid spam
    }
  }, POLL_MS);
}
