import React from "react";
import { TonConnectUIProvider } from "@tonconnect/ui-react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import TonConnectProvider from "./tonconnect/TonConnectProvider.jsx";
import "./styles.css";
import { initTelegramUI, isInTelegram } from "./telegram/webapp.js";

initTelegramUI();

if (isInTelegram()) {
  document.documentElement.classList.add("in-telegram");
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <TonConnectProvider><TonConnectUIProvider manifestUrl={window.location.origin + "/tonconnect-manifest.json"}><App /></TonConnectUIProvider></TonConnectProvider>
  </React.StrictMode>
);
