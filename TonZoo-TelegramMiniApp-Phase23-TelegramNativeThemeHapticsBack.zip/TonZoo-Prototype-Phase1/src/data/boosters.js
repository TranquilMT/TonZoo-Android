/**
 * Boosters are purchased with Coins for purchases.
 * Effects are applied in accrual (tickets/visitors multipliers).
 */
export const BOOSTERS = [
  {
    id: "tickets_x2_1h",
    title: "2× Tickets (1 hour)",
    desc: "Doubles ticket production for 1 hour.",
    durationMs: 60 * 60 * 1000,
    effect: { ticketsMult: 2 },
    cost: { coinsPurchase: 500 },
  },
  {
    id: "visitors_x2_24h",
    title: "2× Visitors (24 hours)",
    desc: "Doubles visitor attraction for 24 hours.",
    durationMs: 24 * 60 * 60 * 1000,
    effect: { visitorsMult: 2 },
    cost: { coinsPurchase: 1000 },
  },
  {
    id: "wheel_free_spin",
    title: "Wheel Free Spin",
    desc: "Adds 1 free Wheel spin (no visitor cost).",
    durationMs: 0,
    effect: { freeWheelSpins: 1 },
    cost: { coinsPurchase: 300 },
  },
];
