export const PAVILIONS = [
  { id: "mini_farm", name: "Mini Farm", theme: "farm", priceCoins: 17000, ticketsPerHour: 3650 },
  { id: "forest_pavilion", name: "Forest Pavilion", theme: "forest", priceCoins: 45000, ticketsPerHour: 10500 },
  { id: "tropical_aviary", name: "Tropical Aviary", theme: "tropical", priceCoins: 115000, ticketsPerHour: 31000 },
  { id: "arctic_aviary", name: "Arctic Aviary", theme: "arctic", priceCoins: 300000, ticketsPerHour: 89000 },
  { id: "reptile_house", name: "Reptile House", theme: "reptile", priceCoins: 160000, ticketsPerHour: 42000 },
  { id: "croc_swamp", name: "Crocodile Swamp", theme: "croc", priceCoins: 220000, ticketsPerHour: 56000 },
  { id: "savanna_pavilion", name: "Savanna Pavilion", theme: "savanna", priceCoins: 775000, ticketsPerHour: 260000 },
  { id: "big_cats_arena", name: "Big Cats Arena", theme: "cats", priceCoins: 450000, ticketsPerHour: 120000 },

  ,{
    id: "event_neon_fox",
    name: "Neon Fox",
    rarity: "Exclusive",
    visitorsPerDay: 38,
    workDays: 7,
    priceVisitors: 950,
    eventOnly: true
  }
];


export const ANIMALS = [
  { id: "penguin", name: "Penguin", rarity: "Normal", workDays: 60, visitorsPerDay: 6, priceVisitors: 180 },
  { id: "gecko", name: "Gecko", rarity: "Normal", workDays: 60, visitorsPerDay: 8, priceVisitors: 250 },
  { id: "turtle", name: "Turtle", rarity: "Special", workDays: 60, visitorsPerDay: 1, priceVisitors: 55 },
  { id: "snake", name: "Snake", rarity: "Special", workDays: 60, visitorsPerDay: 2, priceVisitors: 105 },
  { id: "crocodile", name: "Crocodile", rarity: "Special", workDays: 60, visitorsPerDay: 10, priceVisitors: 380 },
  { id: "lion", name: "Lion", rarity: "Special", workDays: 60, visitorsPerDay: 12, priceVisitors: 450 },

  // Deposit-only bonus animal (unlocked after deposit)
  { id: "ton_panther", name: "TON Panther", rarity: "Exclusive", workDays: 120, visitorsPerDay: 50, priceVisitors: null, depositOnly: true },
];


export const EVENT = {
  id: "neon_week",
  title: "Neon Week",
  endsAt: Date.now() + 1000*60*60*24*3,
  animalId: "event_neon_fox",
  passPriceUsd: 3,
};
