import React, { useEffect, useMemo, useReducer } from "react";
import { PAVILIONS, ANIMALS } from "../data/catalog";
import { DAILY_TASKS, ONETIME_TASKS } from "../data/tasks";
import { BOOSTERS } from "../data/boosters";
import { AUCTION_DURATION_MS, AUCTION_ITEMS } from "../data/auction";
import { nowMs } from "../lib/time";

const LS_KEY = "tonzoo_v27_state";
const API_BASE = import.meta?.env?.VITE_API_BASE || "http://localhost:8787";
const DAY_MS = 24 * 60 * 60 * 1000;

const REF_MILESTONES = [
  { k: 1, title: "Invite 1 friend", reward: { visitors: 500 } },
  { k: 5, title: "Invite 5 friends", reward: { tickets: 5000 } },
  { k: 10, title: "Invite 10 friends", reward: { coinsPurchase: 300 } },
  { k: 25, title: "Invite 25 friends", reward: { visitors: 3000, tickets: 15000 } },
  { k: 50, title: "Invite 50 friends", reward: { coinsPurchase: 1500, tickets: 30000 } },
];

const initial = {
  coinsPurchase: 0,
  coinsWithdraw: 0,
  tickets: 0,
  visitors: 180,

  ownedPavilions: {},
  ownedAnimals: {},

  lastAccrueAt: nowMs(),
  lastActiveAt: Date.now(),

  withdrawals: [],

  lastGameResult: null,
  freeWheelSpins: 0,

  activeBoosters: [],

  dailyResetAt: nowMs(),
  dailyProgress: {},
  dailyClaimed: {},
  oneProgress: {},
  oneClaimed: {},
  dailyVisitorsGained: 0,

  // Auction
  auction: null,
  auctionHistory: [],
  rareAnimalVouchers: 0,

  deposits: [],
  depositIntents: {},
  lastDepositCheckAt: 0,
  depositUsdTotal: 0,

  // Treasury system (Phase A)
  treasuryUsd: 0,
  profitUsd: 0,
  bufferUsd: 0,
  treasurySplit: { treasury: 0.60, profit: 0.30, buffer: 0.10 },
  withdrawalsPaused: false,
  withdrawFeePct: 0.05,
  withdrawDelayMs: 24 * 60 * 60 * 1000,
  withdrawDailyCapUsd: 10,
  withdrawWeeklyCapUsd: 50,
  withdrawalsPaidUsdToday: 0,
  withdrawalsPaidUsdWeek: 0,
  lastWithdrawCapDay: dayKey(),
  lastWithdrawCapWeek: weekKey(),

  // UI FX + onboarding
  uiEvents: [],
  onboarding: { step: 1 },
  tutorialSeen: false,
  soundOn: true,

  // Achievements
  achievements: {},
  achievementsClaimed: {},
  lastBought: { kind: null, id: null, at: 0 },

  // Daily / Offline / Missions
  dailyLogin: { lastDay: null, streak: 0 },
  missions: {
    daily: [
      { id: "buy_animal", title: "Buy 1 animal", goal: 1, progress: 0, reward: { tickets: 500 } },
      { id: "play_game", title: "Play 3 games", goal: 3, progress: 0, reward: { tickets: 800 } },
    ],
    weekly: []
  },

  // Deposit gate
  hasDeposited: false,
  bonusAnimalClaimed: false,

  // Events / leaderboard
  playerName: "",
  eventState: { endsAt: Date.now() + 1000 * 60 * 60 * 24 * 3, passOwned: false, weeklyKey: weekKey(), leaderboardSeed: 1337 },
  eventPoints: 0,
  eventTrack: {
    tiers: [
      { t: 1, need: 200, free: { tickets: 400 }, pass: { tickets: 800 } },
      { t: 2, need: 500, free: { tickets: 600 }, pass: { tickets: 1200 } },
      { t: 3, need: 900, free: { tickets: 900 }, pass: { tickets: 1800 } },
      { t: 4, need: 1400, free: { tickets: 1200 }, pass: { tickets: 2400 } },
      { t: 5, need: 2000, free: { tickets: 1800 }, pass: { tickets: 3600 } }
    ],
    claimedFree: {},
    claimedPass: {}
  },
  eventQuests: {
    dailyKey: dayKey(),
    list: [
      { id: "eq_buy", title: "Buy 1 animal", goal: 1, progress: 0, rewardPts: 120, claimed: false },
      { id: "eq_play", title: "Play 5 games", goal: 5, progress: 0, rewardPts: 180, claimed: false },
      { id: "eq_claim", title: "Claim 1 mission", goal: 1, progress: 0, rewardPts: 120, claimed: false },
    ]
  },
  inbox: [],

  // Referrals (prototype)
  referral: {
    code: null,
    invited: 0,
    active: 0,
    claimed: {},
  },
  referredBy: null,
};

function loadState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return initial;
    const parsed = JSON.parse(raw);
    return ensureReferralCode({ ...initial, ...parsed });
  } catch {
    return ensureReferralCode(initial);
  }
}


function saveState(s) {
  localStorage.setItem(LS_KEY, JSON.stringify(s));
}


function weekKey(ts = Date.now()) {
  const d = new Date(ts);
  const day = (d.getUTCDay() + 6) % 7; // Mon=0
  const monday = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - day));
  return `${monday.getUTCFullYear()}-${monday.getUTCMonth()+1}-${monday.getUTCDate()}`;
}

function dayKey(ts = Date.now()) {
  const d = new Date(ts);
  return `${d.getUTCFullYear()}-${d.getUTCMonth()+1}-${d.getUTCDate()}`;
}



function summonEvent(state, kind, id) {
  return pushUiEvent(state, { type: "summon", kind, id });
}


function addInbox(state, item) {
  return { ...state, inbox: [item, ...(state.inbox || [])].slice(0, 20) };
}

function unlockAchievement(state, id, title) {
  if (state.achievements?.[id]) return state;
  let next = { ...state, achievements: { ...(state.achievements || {}), [id]: true } };
  next = pushUiEvent(next, { type: "achievement", title, id });
  next = pushUiEvent(next, { type: "celebrate" });
  return next;
}

function pushIcon(state, { emoji, text }) {
  return pushUiEvent(state, { type: "icon", emoji, text });
}

function pushUiEvent(state, ev) {
  const e = { id: (action.id || (crypto.randomUUID?.() || String(Math.random()))), at: nowMs(), ...ev };
  const next = { ...state, uiEvents: [ ...(state.uiEvents || []), e ].slice(-8) };
  return next;
}

function ensureReferralCode(state) {
  const existing = state?.referral?.code;
  if (existing) return state;
  const code = ("TZ" + Math.random().toString(36).slice(2, 8)).toUpperCase();
  return { 
    ...state,
    referral: { ...(state.referral || {}), code }
  };
}

function ticketsPerHourTotal(state) {
  let total = 0;
  for (const p of PAVILIONS) {
    const count = state.ownedPavilions[p.id] || 0;
    total += p.ticketsPerHour * count;
  }
  return total;
}

function visitorsPerDayTotal(state) {
  let total = 0;
  for (const a of ANIMALS) {
    const count = state.ownedAnimals[a.id] || 0;
    total += a.visitorsPerDay * count;
  }
  return total;
}

function activeEffects(state, now) {
  let ticketsMult = 1;
  let visitorsMult = 1;

  for (const b of state.activeBoosters || []) {
    if (b.expiresAt && now > b.expiresAt) continue;
    if (b.effect?.ticketsMult) ticketsMult *= b.effect.ticketsMult;
    if (b.effect?.visitorsMult) visitorsMult *= b.effect.visitorsMult;
  }

  return { ticketsMult, visitorsMult };
}

function expireBoosters(state, now) {
  const keep = (state.activeBoosters || []).filter((b) => !b.expiresAt || now <= b.expiresAt);
  if (keep.length === (state.activeBoosters || []).length) return state;
  return { ...state, activeBoosters: keep };
}

function resetDailyIfNeeded(state, now) {
  const resetAt = state.dailyResetAt || now;
  if (now - resetAt < DAY_MS) return state;

  return {
    ...state,
    dailyResetAt: now,
    dailyProgress: {},
    dailyClaimed: {},
    dailyVisitorsGained: 0,
  };
}

function accrue(state, now) {
  state = resetDailyIfNeeded(state, now);
  state = expireBoosters(state, now);
  state = advanceAuction(state, now);

  const last = state.lastAccrueAt || now;
  const dtMs = Math.max(0, now - last);

  const tph = ticketsPerHourTotal(state);
  const vpd = visitorsPerDayTotal(state);

  const eff = activeEffects(state, now);

  const ticketsAdd = (tph / 3600000) * dtMs * eff.ticketsMult;
  const visitorsAdd = (vpd / 86400000) * dtMs * eff.visitorsMult;

  const dailyVisitorsGained = (state.dailyVisitorsGained || 0) + visitorsAdd;

  return {
    ...state,
    tickets: state.tickets + ticketsAdd,
    visitors: state.visitors + visitorsAdd,
    dailyVisitorsGained,
    lastAccrueAt: now,
  };
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function bumpCounter(mapObj, key, by = 1) {
  return { ...mapObj, [key]: (mapObj?.[key] || 0) + by };
}

function applyReward(state, reward) {
  const r = reward || {};
  let next = {
    ...state,
    tickets: state.tickets + (r.tickets || 0),
    visitors: state.visitors + (r.visitors || 0),
    coinsPurchase: state.coinsPurchase + (r.coinsPurchase || 0),
  };

  if (r.rareAnimalVoucher) {
    next.rareAnimalVouchers = (next.rareAnimalVouchers || 0) + r.rareAnimalVoucher;
  }

  return next;
}

function pickAuctionItem(seed = 0) {
  const idx = Math.abs(seed) % AUCTION_ITEMS.length;
  return AUCTION_ITEMS[idx];
}

function startNewAuction(state, now) {
  const seed = (state.auctionHistory?.length || 0) + Math.floor(now / 1000);
  const item = pickAuctionItem(seed);

  const baseBid = randInt(100, 350);
  return {
    ...state,
    auction: {
      id: "auc_" + (crypto.randomUUID?.() || String(Math.random())),
      startsAt: now,
      endsAt: now + AUCTION_DURATION_MS,
      itemId: item.id,
      itemTitle: item.title,
      itemDesc: item.desc,
      itemBadge: item.badge,
      reward: item.reward,
      highestBid: baseBid,
      highestBidder: "bot",
      yourBid: 0,
      minIncrement: 25,
      lastBotBidAt: now,
      settled: false,
    },
  };
}

function settleAuction(state, auction, now) {
  // Refund rule: if you lose, refund 80% of your bid.
  // If you win, no refund; you keep the reward.
  const youWon = auction.highestBidder === "you";
  let next = { ...state };

  if (youWon) {
    next = applyReward(next, auction.reward);
    next = pushUiEvent(next, { type: "toast", title: "Auction won", body: auction.itemTitle });
    next = pushUiEvent(next, { type: "celebrate" });
  } else {
    const refund = Math.floor((auction.yourBid || 0) * 0.8);
    next.visitors += refund;
    next = pushUiEvent(next, { type: "pop", variant: "blue", text: `Auction lost` });
    next = pushIcon(next, { emoji: "👥", text: `Refund +${refund}` });
  }

  next.auctionHistory = [
    ...(next.auctionHistory || []),
    {
      id: auction.id,
      itemId: auction.itemId,
      itemTitle: auction.itemTitle,
      itemBadge: auction.itemBadge,
      finalBid: auction.highestBid,
      winner: auction.highestBidder === "you" ? "you" : "bot",
      endedAt: now,
    },
  ];

  next.auction = null;
  return next;
}

function maybeBotBid(auction, now) {
  // Bot bids every 6-14 seconds, with some randomness.
  const elapsed = now - (auction.lastBotBidAt || auction.startsAt);
  const interval = randInt(6000, 14000);
  if (elapsed < interval) return auction;
  if (now >= auction.endsAt) return auction;

  // If bot already winning, sometimes chill.
  const chill = randInt(1, 100) <= 35;
  if (auction.highestBidder === "bot" && chill) {
    return { ...auction, lastBotBidAt: now };
  }

  const inc = auction.minIncrement || 25;
  const extra = randInt(0, 6) * inc;
  const newBid = auction.highestBid + inc + extra;

  return {
    ...auction,
    highestBid: newBid,
    highestBidder: "bot",
    lastBotBidAt: now,
  };
}

function advanceAuction(state, now) {
  // ensure auction exists
  if (!state.auction) {
    return startNewAuction(state, now);
  }

  const a = state.auction;

  // If ended and not settled -> settle and start next after short delay (we start immediately for prototype)
  if (now >= a.endsAt) {
    return startNewAuction(settleAuction(state, a, now), now);
  }

  // update bot bids
  const nextA = maybeBotBid(a, now);
  if (nextA === a) return state;
  return { ...state, auction: nextA };
}

function reducer(state, action) {
  const now = nowMs();
  let s = accrue(state, now);

  
switch (action.type) {

    case "APP_BOOT": {
      let next = { ...s };
      const now = Date.now();

      // Offline progress (tickets per hour)
      const hoursAway = Math.max(0, (now - (s.lastActiveAt || now)) / 36e5);
      if (hoursAway > 0.05) {
        const mult = (s.eventState?.passOwned) ? 1.1 : 1.0;
      const ticketsGained = Math.floor(hoursAway * (s.ticketsPerHour || 0) * mult);
        if (ticketsGained > 0) {
          next.tickets += ticketsGained;
          next = pushUiEvent(next, { type: "toast", title: "Offline progress", body: `+${ticketsGained} tickets while away` });
          next = pushIcon(next, { emoji: "🎟️", text: `+${ticketsGained}` });
        }
      }

      // Weekly reset (leaderboard)
      const wk = weekKey(now);
      if ((s.eventState?.weeklyKey || wk) !== wk) {
        // Determine last week's rank (approx) and grant prizes (prototype)
        const playerScore = s.visitors || 0;
        const seed = (s.eventState?.leaderboardSeed || 1337) + playerScore;
        let x = seed % 2147483647; if (x<=0) x += 2147483646;
        const rnd = () => (x = (x * 16807) % 2147483647) / 2147483647;
        const base = Math.max(500, Math.floor(playerScore * 1.2));
        const bots = Array.from({length:7}).map((_,i)=> (base + Math.floor(rnd()*2500) + i*120));
        const all = bots.concat([playerScore]).sort((a,b)=>b-a);
        const rank = all.indexOf(playerScore) + 1;

        let prize = 0;
        if (rank === 1) prize = 4000;
        else if (rank === 2) prize = 2500;
        else if (rank === 3) prize = 1500;
        else if (rank <= 8) prize = 600;

        if (prize > 0) {
          next = addInbox(next, { id: "lb_" + (s.eventState?.weeklyKey || "wk"), title: "Leaderboard Prize", body: `Rank #${rank} — +${prize} tickets`, tickets: prize, createdAt: now });
          next = pushUiEvent(next, { type: "toast", title: "Weekly prize", body: `Rank #${rank} reward added to Inbox` });
        }

        next.eventState = { ...(next.eventState || {}), weeklyKey: wk, leaderboardSeed: Math.floor(Math.random()*999999) };
        next = pushUiEvent(next, { type: "toast", title: "Weekly reset", body: "Leaderboard refreshed" });
      }

      // withdraw cap reset
      const dk2 = dayKey(now);
      const wk2 = weekKey(now);
      if ((s.lastWithdrawCapDay || dk2) !== dk2) {
        next.withdrawalsPaidUsdToday = 0;
        next.lastWithdrawCapDay = dk2;
      }
      if ((s.lastWithdrawCapWeek || wk2) !== wk2) {
        next.withdrawalsPaidUsdWeek = 0;
        next.lastWithdrawCapWeek = wk2;
      }

      // Event quests reset (daily)
      const dk = dayKey(now);
      if ((s.eventQuests?.dailyKey || dk) !== dk) {
        next.eventQuests = {
          dailyKey: dk,
          list: [
            { id: "eq_buy", title: "Buy 1 animal", goal: 1, progress: 0, rewardPts: 120, claimed: false },
            { id: "eq_play", title: "Play 5 games", goal: 5, progress: 0, rewardPts: 180, claimed: false },
            { id: "eq_claim", title: "Claim 1 mission", goal: 1, progress: 0, rewardPts: 120, claimed: false }
          ]
        };
        next = pushUiEvent(next, { type: "toast", title: "Event quests", body: "New daily quests available" });
      }

      // Daily login
      const today = dayKey(now);
      if (s.dailyLogin.lastDay !== today) {
        const streak = s.dailyLogin.lastDay ? s.dailyLogin.streak + 1 : 1;
        next.dailyLogin = { lastDay: today, streak };
        const reward = 300 + Math.min(7, streak) * 200;
        next.tickets += reward;
        next = pushUiEvent(next, { type: "toast", title: `Daily login Day ${streak}`, body: `+${reward} tickets` });
        next = pushIcon(next, { emoji: "🔥", text: `Streak ${streak}` });
        if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      }

      next.lastActiveAt = now;
      return next;
    }


    case "ACK_UI_EVENT": {
      const id = action.id;
      if (!id) return s;
      return { ...s, uiEvents: (s.uiEvents || []).filter((e) => e.id !== id) };
    }

    case "ADVANCE_ONBOARDING": {
      const step = (s.onboarding?.step || 0) + 1;
      return { ...s, onboarding: { step } };
    }

    case "CLAIM_ACHIEVEMENT": {
      const { id } = action;
      if (!id) return s;
      if (!s.achievements?.[id]) return s;
      if (s.achievementsClaimed?.[id]) return s;
      // simple rewards
      const reward = (id === "big_win") ? 1500 : 600;
      let next = { ...s, tickets: s.tickets + reward, achievementsClaimed: { ...(s.achievementsClaimed||{}), [id]: true } };
      next = pushUiEvent(next, { type: "toast", title: "Achievement claimed", body: `+${reward} tickets` });
      next = pushIcon(next, { emoji: "🏆", text: `+${reward}` });
      return next;
    }

    
case "SET_PLAYER_NAME": {
      const name = (action.name || "").slice(0, 16);
      return { ...s, playerName: name };
    }

    case "BUY_EVENT_PASS": {
      const price = Number(action.priceUsd) || 3;
      if ((s.depositUsdTotal || 0) < price) {
        let out = pushUiEvent(s, { type: "toast", title: "Event Pass", body: `Deposit $${price} total to buy pass.` });
        out = pushIcon(out, { emoji: "💎", text: `$${price}` });
        return out;
      }
      let next = { ...s, eventState: { ...(s.eventState || {}), passOwned: true } };
      next = pushUiEvent(next, { type: "toast", title: "Event Pass", body: "Pass activated (+10% tickets)" });
      if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      return next;
    }

    case "BUY_EVENT_ANIMAL": {
      const id = action.id;
      const price = Number(action.priceVisitors) || 950;
      const now = Date.now();
      if (now > (s.eventState?.endsAt || 0)) {
        return pushUiEvent(s, { type: "toast", title: "Event ended", body: "This animal is no longer available." });
      }
      if (s.visitors < price) return s;
      let next = { ...s, visitors: s.visitors - price };
      next.ownedAnimals = { ...(s.ownedAnimals || {}), [id]: (s.ownedAnimals?.[id] || 0) + 1 };
      next.lastBought = { kind: "animal", id, at: now };
      let out = summonEvent(next, "animal", id);
      out = pushUiEvent(out, { type: "toast", title: "Limited animal bought", body: "Neon Fox joined your zoo" });
      out = pushUiEvent(out, { type: "celebrate" });
      return out;
    }

    case "CLAIM_INBOX": {
      const id = action.id;
      const item = (s.inbox || []).find((x) => x.id === id);
      if (!item) return s;
      let next = { ...s, inbox: (s.inbox || []).filter((x) => x.id !== id) };
      if (item.tickets) {
        next.tickets += item.tickets;
        next = pushIcon(next, { emoji: "📬", text: `+${item.tickets}` });
      }
      next = pushUiEvent(next, { type: "toast", title: "Claimed", body: item.title });
      return next;
    }

    case "CLAIM_EVENT_QUEST": {
      const id = action.id;
      const q = (s.eventQuests?.list || []).find((x) => x.id === id);
      if (!q || q.claimed || q.progress < q.goal) return s;
      let next = { ...s };
      next.eventPoints = (s.eventPoints || 0) + (q.rewardPts || 0);
      next.eventQuests = { ...s.eventQuests, list: (s.eventQuests?.list || []).map((x) => (x.id === id ? { ...x, claimed: true } : x)) };
      next = pushUiEvent(next, { type: "toast", title: "Quest complete", body: `+${q.rewardPts} event points` });
      next = pushIcon(next, { emoji: "✨", text: `+${q.rewardPts}` });
      return next;
    }

    case "CLAIM_TRACK_TIER": {
      const tier = Number(action.tier);
      const isPass = !!action.isPass;
      const t = (s.eventTrack?.tiers || []).find((x) => x.t === tier);
      if (!t) return s;
      if ((s.eventPoints || 0) < t.need) return s;

      const claimedMap = isPass ? (s.eventTrack?.claimedPass || {}) : (s.eventTrack?.claimedFree || {});
      if (claimedMap[tier]) return s;
      if (isPass && !s.eventState?.passOwned) return s;

      const reward = isPass ? t.pass : t.free;
      let next = { ...s };
      if (reward?.tickets) next.tickets += reward.tickets;

      next.eventTrack = {
        ...s.eventTrack,
        claimedFree: isPass ? (s.eventTrack?.claimedFree || {}) : { ...(s.eventTrack?.claimedFree || {}), [tier]: true },
        claimedPass: isPass ? { ...(s.eventTrack?.claimedPass || {}), [tier]: true } : (s.eventTrack?.claimedPass || {}),
      };

      next = pushUiEvent(next, { type: "toast", title: "Track reward", body: `Tier ${tier} claimed` });
      next = pushIcon(next, { emoji: isPass ? "💎" : "🎁", text: `+${reward?.tickets || 0}` });
      if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      return next;
    }

    case "CREATE_DEPOSIT_INTENT": {
      const dep = action.deposit;
      const pay = action.pay;
      if (!dep?.id) return s;
      const intents = { ...(s.depositIntents || {}), [dep.id]: { ...dep, pay } };
      let out = { ...s, depositIntents: intents };
      out = pushUiEvent(out, { type: "toast", title: "Deposit created", body: `Send with comment TONZOO:${dep.id}` });
      return out;
    }

    case "APPLY_CONFIRMED_DEPOSITS": {
      const list = action.confirmed || [];
      if (!Array.isArray(list) || list.length === 0) return s;
      let next = { ...s, lastDepositCheckAt: Date.now() };

      for (const dep of list) {
        if (!dep?.id) continue;
        // prevent double apply
        if ((next.deposits || []).some((d) => d.id === dep.id && d.status === "Confirmed")) continue;

        const usd = Math.max(1, Number(dep.usd) || 1);
        const ssplit = (dep.split || null);
        const tAdd = ssplit ? Number(ssplit.tAdd||0) : (usd * (split.treasury ?? 0.6));
        const pAdd = ssplit ? Number(ssplit.pAdd||0) : (usd * (split.profit ?? 0.3));
        const bAdd = ssplit ? Number(ssplit.bAdd||0) : (usd * (split.buffer ?? 0.1));
        const coinsAdd = ssplit ? Math.floor(Number(ssplit.coinsAdd||0)) : Math.floor(usd * 1000);

        next.deposits = [...(next.deposits || []), { ...dep, status: "Confirmed" }];
        next.hasDeposited = true;
        next.depositUsdTotal = (next.depositUsdTotal || 0) + usd;
        next.treasuryUsd = (next.treasuryUsd || 0) + tAdd;
        next.profitUsd = (next.profitUsd || 0) + pAdd;
        next.bufferUsd = (next.bufferUsd || 0) + bAdd;
        next.coinsPurchase = (next.coinsPurchase || 0) + coinsAdd;
        next.coins = (next.coins || 0) + coinsAdd;
      }

      if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      next = pushUiEvent(next, { type: "toast", title: "Deposit confirmed", body: "Coins credited" });
      return next;
    }

    case "APPLY_SERVER_LEDGER": {
      const l = action.ledger;
      if (!l) return s;
      return {
        ...s,
        treasuryUsd: Number(l.treasuryUsd || 0),
        profitUsd: Number(l.profitUsd || 0),
        bufferUsd: Number(l.bufferUsd || 0),
        withdrawalsPaused: !!l.withdrawalsPaused,
        withdrawFeePct: Number(l.withdrawFeePct ?? s.withdrawFeePct),
        withdrawDelayMs: Number(l.withdrawDelayMs ?? s.withdrawDelayMs),
        withdrawDailyCapUsd: Number(l.withdrawDailyCapUsd ?? s.withdrawDailyCapUsd),
        withdrawWeeklyCapUsd: Number(l.withdrawWeeklyCapUsd ?? s.withdrawWeeklyCapUsd),
        withdrawalsPaidUsdToday: Number(l.paidTodayUsd ?? s.withdrawalsPaidUsdToday),
        withdrawalsPaidUsdWeek: Number(l.paidWeekUsd ?? s.withdrawalsPaidUsdWeek),
      };
    }

    case "ADMIN_SET_TREASURY_CONFIG": {
      const next = { ...s };
      if (action.split) next.treasurySplit = { ...next.treasurySplit, ...action.split };
      if (typeof action.withdrawFeePct === "number") next.withdrawFeePct = Math.max(0, Math.min(0.2, action.withdrawFeePct));
      if (typeof action.withdrawDelayMs === "number") next.withdrawDelayMs = Math.max(0, action.withdrawDelayMs);
      if (typeof action.withdrawDailyCapUsd === "number") next.withdrawDailyCapUsd = Math.max(0, action.withdrawDailyCapUsd);
      if (typeof action.withdrawWeeklyCapUsd === "number") next.withdrawWeeklyCapUsd = Math.max(0, action.withdrawWeeklyCapUsd);
      return next;
    }

    case "ADMIN_TOGGLE_WITHDRAWALS": {
      return { ...s, withdrawalsPaused: !s.withdrawalsPaused };
    }

    case "ADMIN_PROCESS_READY": {
      // Process any Ready withdrawals if delay passed & treasury has enough
      const now2 = now;
      const feePct = s.withdrawFeePct ?? 0.05;
      const delay = s.withdrawDelayMs ?? (24*60*60*1000);

      // reset caps if day/week changed
      let next = { ...s };
      const dk = dayKey(now2);
      const wk = weekKey(now2);
      if ((next.lastWithdrawCapDay || dk) !== dk) { next.withdrawalsPaidUsdToday = 0; next.lastWithdrawCapDay = dk; }
      if ((next.lastWithdrawCapWeek || wk) !== wk) { next.withdrawalsPaidUsdWeek = 0; next.lastWithdrawCapWeek = wk; }

      const capDay = next.withdrawDailyCapUsd ?? 10;
      const capWeek = next.withdrawWeeklyCapUsd ?? 50;

      const ws = (next.withdrawals || []).map((w) => ({ ...w }));
      for (const w of ws) {
        if (w.status !== "Pending") continue;
        if ((w.processAfter || 0) > now2) continue;

        const usd = Number(w.usd) || 0;
        const net = Math.max(0, +(usd * (1 - feePct)).toFixed(2));

        if (next.withdrawalsPaused) { w.status = "Paused"; continue; }
        if ((next.treasuryUsd || 0) < net) { w.status = "Insufficient treasury"; continue; }
        if ((next.withdrawalsPaidUsdToday || 0) + net > capDay) { w.status = "Daily cap reached"; continue; }
        if ((next.withdrawalsPaidUsdWeek || 0) + net > capWeek) { w.status = "Weekly cap reached"; continue; }

        // pay
        next.treasuryUsd = +( (next.treasuryUsd || 0) - net ).toFixed(2);
        next.withdrawalsPaidUsdToday = +( (next.withdrawalsPaidUsdToday || 0) + net ).toFixed(2);
        next.withdrawalsPaidUsdWeek = +( (next.withdrawalsPaidUsdWeek || 0) + net ).toFixed(2);
        w.status = "Paid";
        w.paidAt = now2;
        w.netUsd = net;
      }

      next.withdrawals = ws;
      next = pushUiEvent(next, { type: "toast", title: "Admin", body: "Processed ready withdrawals" });
      return next;
    }

    case "TOGGLE_SOUND": {

      return { ...s, soundOn: !s.soundOn };
    }

    case "FINISH_TUTORIAL": {
      return { ...s, tutorialSeen: true };
    }

    case "RESET":
      return { ...initial, lastAccrueAt: now, dailyResetAt: now };

    case "__TICK__":
      // Just accrue (includes auction advance)
      return s;

    case "BUY_PAVILION": {
      const p = PAVILIONS.find((x) => x.id === action.id);
      if (!p) return s;
      if (s.coinsPurchase < p.priceCoins) return s;

      const next = {
        ...s,
        coinsPurchase: s.coinsPurchase - p.priceCoins,
        ownedPavilions: { ...s.ownedPavilions, [p.id]: (s.ownedPavilions[p.id] || 0) + 1 },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "pavilion_bought", 1);
      next.oneProgress = bumpCounter(next.oneProgress, "pavilion_bought", 1);
      next.lastBought = { kind: "pavilion", id: action.id, at: Date.now() };
      let out = summonEvent(next, "pavilion", action.id);
      out = pushUiEvent(out, { type: "pop", variant: "blue", text: "Pavilion bought" });
      out = pushIcon(out, { emoji: "🎟️", text: "+ tickets/hr" });
      out = unlockAchievement(out, "first_pavilion", "First Pavilion");
      return out;
    }

    
case "BUY_ANIMAL": {

      const a = ANIMALS.find((x) => x.id === action.id);
      if (!a || a.locked) return s;
      if (a.priceVisitors == null) return s;
      if (s.visitors < a.priceVisitors) return s;

      const next = {
        ...s,
        visitors: s.visitors - a.priceVisitors,
        ownedAnimals: { ...s.ownedAnimals, [a.id]: (s.ownedAnimals[a.id] || 0) + 1 },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "animal_bought", 1);
      next.oneProgress = bumpCounter(next.oneProgress, "animal_bought", 1);
      
// Mission progress
if (next.missions?.daily) {
  next.missions.daily = next.missions.daily.map(m =>
    m.id === "buy_animal" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m
  );
}

let out = pushUiEvent(next, { type: "pop", variant: "pink", text: "Animal bought" });

      out = pushIcon(out, { emoji: "👥", text: "+ visitors/day" });
      return out;
    }

    case "EXCHANGE_TICKETS": {
      const batch = Math.floor(s.tickets / 300);
      if (batch <= 0) return s;

      const next = {
        ...s,
        tickets: s.tickets - batch * 300,
        coinsPurchase: s.coinsPurchase + batch * 2,
        coinsWithdraw: s.coinsWithdraw + batch * 1,
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "exchange", 1);
      let out = pushUiEvent(next, { type: "toast", title: "Exchanged tickets", body: `+${batch*2} purchase coins, +${batch} withdraw coins` });
      out = pushIcon(out, { emoji: "🟩", text: `+${batch*2}` });
      out = pushIcon(out, { emoji: "⬜", text: `+${batch}` });
      return out;
    }

    case "SIM_TOPUP": {
      const usd = Math.max(0, Number(action.usd) || 0);
      const visitorsAdd = Math.floor(usd * 300);

      return {
        ...s,
        coinsPurchase: s.coinsPurchase + Math.floor(usd * 1000),
        visitors: s.visitors + visitorsAdd,
        dailyVisitorsGained: (s.dailyVisitorsGained || 0) + visitorsAdd,
      };
    }

    case "BUY_BOOSTER": {
      const b = BOOSTERS.find((x) => x.id === action.id);
      if (!b) return s;

      const cost = b.cost?.coinsPurchase || 0;
      if (s.coinsPurchase < cost) return s;

      let next = { ...s, coinsPurchase: s.coinsPurchase - cost };

      if (b.effect?.freeWheelSpins) {
        next.freeWheelSpins = (next.freeWheelSpins || 0) + b.effect.freeWheelSpins;
      }

      if (b.durationMs && (b.effect?.ticketsMult || b.effect?.visitorsMult)) {
        next.activeBoosters = [
          ...(next.activeBoosters || []),
          { id: b.id, effect: b.effect, expiresAt: now + b.durationMs },
        ];
      }

      return next;
    }

    
case "PLAY_WHEEL": {

      const cost = 50;
      const hasFree = (s.freeWheelSpins || 0) > 0;

      if (!hasFree && s.visitors < cost) return s;

      const outcomes = [
        { tickets: 0, weight: 20, label: "Try Again" },
        { tickets: 200, weight: 25, label: "+200 tickets" },
        { tickets: 500, weight: 20, label: "+500 tickets" },
        { tickets: 1000, weight: 18, label: "+1,000 tickets" },
        { tickets: 2000, weight: 12, label: "+2,000 tickets" },
        { tickets: 5000, weight: 5, label: "+5,000 tickets" },
      ];

      const totalW = outcomes.reduce((a, b) => a + b.weight, 0);
      let r = randInt(1, totalW);
      let pick = outcomes[0];
      for (const o of outcomes) {
        r -= o.weight;
        if (r <= 0) { pick = o; break; }
      }

      const next = {
        ...s,
        visitors: hasFree ? s.visitors : (s.visitors - cost),
        freeWheelSpins: hasFree ? (s.freeWheelSpins - 1) : s.freeWheelSpins,
        tickets: s.tickets + pick.tickets,
        lastGameResult: { game: "wheel", label: pick.label, tickets: pick.tickets, costVisitors: hasFree ? 0 : cost, at: now },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "wheel_spin", 1);
      const celebrate = (pick.tickets || 0) >= 2000;
      
// Mission progress
if (next.missions?.daily) {
  next.missions.daily = next.missions.daily.map(m =>
    m.id === "play_game" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m
  );
}

let out = pushUiEvent(next, { type: "pop", variant: celebrate ? "green" : "blue", text: `Wheel win` });

      out = pushIcon(out, { emoji: "🎟️", text: `+${pick.tickets}` });
      if (celebrate) {
        out = pushUiEvent(out, { type: "celebrate" });
        out = unlockAchievement(out, "big_win", "Big Win!");
      }
      return out;
    }

    case "PLAY_SLOTS": {
      const cost = 100;
      if (s.visitors < cost) return s;

      const symbols = ["🦁", "🐧", "🐍", "🐊", "🦜", "🦓"];
      const a = symbols[randInt(0, symbols.length - 1)];
      const b = symbols[randInt(0, symbols.length - 1)];
      const c = symbols[randInt(0, symbols.length - 1)];

      let winTickets = 0;
      let label = "No win";

      if (a === b && b === c) {
        winTickets = 6000;
        label = "JACKPOT! +6,000 tickets";
      } else if (a === b || b === c || a === c) {
        winTickets = 1500;
        label = "Win! +1,500 tickets";
      } else {
        winTickets = 200;
        label = "+200 tickets";
      }

      const next = {
        ...s,
        visitors: s.visitors - cost,
        tickets: s.tickets + winTickets,
        lastGameResult: {
          game: "slots",
          label,
          reels: [a, b, c],
          tickets: winTickets,
          costVisitors: cost,
          at: now,
        },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "slots_spin", 1);
      const celebrate = winTickets >= 6000;
      let out = pushUiEvent(next, { type: "pop", variant: celebrate ? "green" : "blue", text: "Slots result" });
      out = pushIcon(out, { emoji: "🎟️", text: `${winTickets >= 0 ? "+" : ""}${winTickets}` });
      out = pushUiEvent(out, { type: "toast", title: "Slots", body: label });
      if (celebrate) {
        out = pushUiEvent(out, { type: "celebrate" });
        out = unlockAchievement(out, "big_win", "Big Win!");
      }
      return out;
    }

    case "PLACE_AUCTION_BID": {
      const bid = Math.max(0, Math.floor(Number(action.bid) || 0));
      if (!s.auction) return s;

      const a = s.auction;
      if (now >= a.endsAt) return s;

      const minNext = (a.highestBid || 0) + (a.minIncrement || 25);
      if (bid < minNext) return s;

      // Additional visitors needed beyond your current bid (escrow)
      const delta = Math.max(0, bid - (a.yourBid || 0));
      if (s.visitors < delta) return s;

      return {
        ...s,
        visitors: s.visitors - delta,
        auction: {
          ...a,
          yourBid: bid,
          highestBid: bid,
          highestBidder: "you",
        },
      };
    }

    case "CLAIM_TASK": {
      const { taskId, scope } = action;
      const isDaily = scope === "daily";

      const def = isDaily
        ? DAILY_TASKS.find((t) => t.id === taskId)
        : ONETIME_TASKS.find((t) => t.id === taskId);

      if (!def) return s;

      if (isDaily && s.dailyClaimed?.[taskId]) return s;
      if (!isDaily && s.oneClaimed?.[taskId]) return s;

      let done = false;

      if (def.kind === "counter") {
        const key = def.event;
        const val = isDaily ? (s.dailyProgress?.[key] || 0) : (s.oneProgress?.[key] || 0);
        done = val >= def.target;
      } else if (def.kind === "accum") {
        const val = s.dailyVisitorsGained || 0;
        done = val >= def.target;
      } else if (def.kind === "state_check") {
        const val = s[def.stateField] || 0;
        done = val >= def.target;
      }

      if (!done) return s;

      let next = applyReward(s, def.reward);

      if (isDaily) {
        next.dailyClaimed = { ...(next.dailyClaimed || {}), [taskId]: true };
      } else {
        next.oneClaimed = { ...(next.oneClaimed || {}), [taskId]: true };
      }

      return next;
    }
case "RECORD_DEPOSIT": {
      const amountTon = Math.max(0, Number(action.amountTon) || 0);
      if (amountTon <= 0) return s;

      const dep = {
        id: "dep_" + (crypto.randomUUID?.() || String(Math.random())),
        amountTon: Number(amountTon.toFixed(4)),
        usd: Math.max(0, Number(action.usd) || 0),
        treasury: action.treasury || "",
        status: "Pending",
        createdAt: now,
      };

      return { ...s, deposits: [...(s.deposits || []), dep] };
    }

    case "CONFIRM_DEPOSIT": {
      const id = action.id;
      const deps = (s.deposits || []).map((d) =>
        d.id === id ? { ...d, status: "Confirmed", confirmedAt: now } : d
      );
      const dep = (s.deposits || []).find((d) => d.id === id);
      const usd = Math.max(0, Number(dep?.usd) || 0) || 1; // fallback to $1 minimum for prototype
      const wasConfirmed = (dep?.status === "Confirmed");
      if (wasConfirmed) return s;

      const split = s.treasurySplit || { treasury: 0.6, profit: 0.3, buffer: 0.1 };
      const tAdd = usd * (split.treasury ?? 0.6);
      const pAdd = usd * (split.profit ?? 0.3);
      const bAdd = usd * (split.buffer ?? 0.1);
      const coinsAdd = Math.floor(usd * 1000);
      let out = { ...s, deposits: deps, hasDeposited: true, depositUsdTotal: (s.depositUsdTotal || 0) + usd,
        treasuryUsd: (s.treasuryUsd || 0) + tAdd,
        profitUsd: (s.profitUsd || 0) + pAdd,
        bufferUsd: (s.bufferUsd || 0) + bAdd,
        coinsPurchase: (s.coinsPurchase || 0) + coinsAdd,
        coins: (s.coins || 0) + coinsAdd,
      };
      out = pushUiEvent(out, { type: "toast", title: "Deposit confirmed", body: "Deposit-only animal unlocked" });
      out = pushIcon(out, { emoji: "💎", text: "Unlocked" });
      out = pushUiEvent(out, { type: "celebrate" });
      return out;
    }

    case "PROCESS_WITHDRAWAL": {
      const { id, status } = action;
      if (!id || !status) return s;
      const ws = (s.withdrawals || []).map((w) =>
        w.id === id ? { ...w, status } : w
      );
      return { ...s, withdrawals: ws };
    }

    case "SIM_DEPOSIT": {
      const usd = Math.max(1, Number(action.usd) || 1);
      const amountTon = Math.max(0.1, Number(action.amountTon) || Number((usd / 5).toFixed(3))); // rough
      const id = "dep_" + (crypto.randomUUID?.() || String(Math.random()));
      const dep = {
        id,
        amountTon: Number(amountTon.toFixed(4)),
        usd,
        treasury: action.treasury || "",
        status: "Confirmed",
        createdAt: now,
        confirmedAt: now,
      };

      // split
      const split = s.treasurySplit || { treasury: 0.6, profit: 0.3, buffer: 0.1 };
      const tAdd = usd * (split.treasury ?? 0.6);
      const pAdd = usd * (split.profit ?? 0.3);
      const bAdd = usd * (split.buffer ?? 0.1);

      // credit purchased coins ($1 = 1000 coins)
      const coinsAdd = Math.floor(usd * 1000);

      let out = {
        ...s,
        deposits: [...(s.deposits || []), dep],
        hasDeposited: true,
        depositUsdTotal: (s.depositUsdTotal || 0) + usd,
        treasuryUsd: (s.treasuryUsd || 0) + tAdd,
        profitUsd: (s.profitUsd || 0) + pAdd,
        bufferUsd: (s.bufferUsd || 0) + bAdd,
        coinsPurchase: (s.coinsPurchase || 0) + coinsAdd,
        coins: (s.coins || 0) + coinsAdd,
      };

      out = pushUiEvent(out, { type: "toast", title: "Deposit simulated", body: `+$${usd} → +${coinsAdd} coins` });
      out = pushIcon(out, { emoji: "💰", text: `+$${usd}` });
      out = pushUiEvent(out, { type: "celebrate" });
      return out;
    }

case "CLAIM_BONUS_ANIMAL": {
  // Claim deposit-only bonus animal once for free (1A)
  if (!s.hasDeposited) return s;
  if (s.bonusAnimalClaimed) return s;
  const id = "ton_panther";
  return {
    ...s,
    bonusAnimalClaimed: true,
    ownedAnimals: { ...s.ownedAnimals, [id]: (s.ownedAnimals[id] || 0) + 1 },
  };
}

case "SET_REFERRER": {
      const code = (action.code || "").trim();
      if (!code) return s;
      // prevent self-ref (when referral code exists)
      if (code && s.referral?.code && code === s.referral.code) return s;
      if (s.referredBy) return s; // only set once in prototype
      return { ...s, referredBy: code };
    }

    case "SIM_REF_INVITE": {

  const invited = (s.referral?.invited || 0) + 1;
  // In prototype, randomly mark some invited as active
  const active = (s.referral?.active || 0) + (Math.random() < 0.6 ? 1 : 0);
  return {
    ...s,
    referral: { ...(s.referral || {}), invited, active, claimed: (s.referral?.claimed || {}) },
  };
}

case "CLAIM_REF_MILESTONE": {
  const k = Number(action.k) || 0;
  const m = REF_MILESTONES.find((x) => x.k === k);
  if (!m) return s;
  const claimed = !!s.referral?.claimed?.[k];
  if (claimed) return s;
  if ((s.referral?.invited || 0) < k) return s;

  const next = applyReward(s, m.reward);
  return {
    ...next,
    referral: {
      ...(next.referral || {}),
      claimed: { ...(next.referral?.claimed || {}), [k]: true },
    },
  };
}


    
case "CLAIM_MISSION": {
  const { scope, id } = action;
  const list = s.missions?.[scope] || [];
  const m = list.find(x => x.id === id);
  if (!m || m.progress < m.goal) return s;

  let next = { ...s };
  if (m.reward?.tickets) {
    next.tickets += m.reward.tickets;
    next = pushIcon(next, { emoji: "🎯", text: `+${m.reward.tickets}` });
  }
  next.missions[scope] = list.filter(x => x.id !== id);
  next = pushUiEvent(next, { type: "toast", title: "Mission complete", body: m.title });
      // Event quest progress
      if (next.eventQuests?.list) {
        next.eventQuests = { ...next.eventQuests, list: next.eventQuests.list.map(q => q.id === "eq_claim" ? { ...q, progress: Math.min(q.goal, q.progress + 1) } : q) };
      }
  next = pushUiEvent(next, { type: "celebrate" });
  return next;
}

case "REQUEST_WITHDRAW": {

      const wallet = (action.wallet || "").trim();
      const coins = Math.max(0, Math.floor(Number(action.coins) || 0));
      const feePct = s.withdrawFeePct ?? 0.05;
      const delay = s.withdrawDelayMs ?? (24*60*60*1000);
      if (coins < 1000) return s;
      if ((s.depositUsdTotal || 0) < 1) return s;
      if (s.withdrawalsPaused) return s;
      if (s.visitors < 1000) return s;
      if (s.coinsWithdraw < coins) return s;
      const usd = +(coins / 1000).toFixed(2);
      const net = Math.max(0, +(usd * (1 - feePct)).toFixed(2));
      if (wallet.length < 10) return s;

      const next = {
        ...s,
        coinsWithdraw: s.coinsWithdraw - coins,
        withdrawals: [
          ...s.withdrawals,
          {
            id: (action.id || (crypto.randomUUID?.() || String(Math.random()))),
            processAfter: now + delay,
            feePct,
            netUsd: net,
            wallet,
            coins,
            usd: coins / 1000,
            status: "Pending",
            createdAt: now,
          },
        ],
      };
      let out = pushUiEvent(next, { type: "toast", title: "Withdrawal requested", body: "Added to queue (prototype)" });
      out = pushIcon(out, { emoji: "⬜", text: `-${coins}` });
      return out;
    }

    default:
      return s;
  }
}

export function useGameState() {
  const [state, dispatch] = useReducer(reducer, undefined, loadState);

  useEffect(() => {
    const t = setInterval(() => dispatch({ type: "__TICK__" }), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    saveState(state);
  }, [state]);

  const derived = useMemo(() => ({
    ticketsPerHour: Math.floor(ticketsPerHourTotal(state)),
    visitorsPerDay: Math.floor(visitorsPerDayTotal(state)),
  }), [state]);

  const actions = useMemo(() => ({
    buyPavilion: (id) => dispatch({ type: "BUY_PAVILION", id }),
    buyAnimal: (id) => dispatch({ type: "BUY_ANIMAL", id }),
    exchangeTickets: () => dispatch({ type: "EXCHANGE_TICKETS" }),
    simTopUp: (usd) => dispatch({ type: "SIM_TOPUP", usd }),
    playWheel: () => dispatch({ type: "PLAY_WHEEL" }),
    playSlots: () => dispatch({ type: "PLAY_SLOTS" }),
    buyBooster: (id) => dispatch({ type: "BUY_BOOSTER", id }),
    placeAuctionBid: (bid) => dispatch({ type: "PLACE_AUCTION_BID", bid }),
    recordDeposit: ({ amountTon, usd, treasury }) => dispatch({ type: "RECORD_DEPOSIT", amountTon, usd, treasury }),
    confirmDeposit: (id) => dispatch({ type: "CONFIRM_DEPOSIT", id }),
    simDeposit: (usd, amountTon, treasury) => dispatch({ type: "SIM_DEPOSIT", usd, amountTon, treasury }),

    createDepositIntent: async (currency,
            processAfter: action.processAfter || (now + (s.withdrawDelayMs ?? 0)),
            feePct: action.feePct ?? (s.withdrawFeePct ?? 0.05),
            netUsd: action.netUsd ?? undefined, usd, expectedNano) => {
      const res = await fetch(`${API_BASE}/api/deposits/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currency,
            processAfter: action.processAfter || (now + (s.withdrawDelayMs ?? 0)),
            feePct: action.feePct ?? (s.withdrawFeePct ?? 0.05),
            netUsd: action.netUsd ?? undefined, usd, expectedNano })
      });
      const j = await res.json();
      if (j?.deposit?.id) dispatch({ type: "CREATE_DEPOSIT_INTENT", deposit: j.deposit, pay: j.pay });
      return j;
    },

    refreshLedger: async () => {
      const res = await fetch(`${API_BASE}/api/admin/status`);
      const j = await res.json();
      if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },

    requestWithdrawServer: async (address, currency,
            processAfter: action.processAfter || (now + (s.withdrawDelayMs ?? 0)),
            feePct: action.feePct ?? (s.withdrawFeePct ?? 0.05),
            netUsd: action.netUsd ?? undefined, coins) => {
      const usd = +(Math.floor(coins) / 1000).toFixed(2);
      const res = await fetch(`${API_BASE}/api/withdrawals/request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: "local", address, currency,
            processAfter: action.processAfter || (now + (s.withdrawDelayMs ?? 0)),
            feePct: action.feePct ?? (s.withdrawFeePct ?? 0.05),
            netUsd: action.netUsd ?? undefined, usd })
      });
      const j = await res.json();
      if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },

    processWithdrawalsServer: async () => {
      const res = await fetch(`${API_BASE}/api/withdrawals/process`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      const j = await res.json();
      if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      if (j?.paid?.length) dispatch({ type: "APPLY_PAID_WITHDRAWALS", paid: j.paid });
      return j;
    },

    demoConfirmDeposit: async (id) => {
      const res = await fetch(`${API_BASE}/api/demo/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      const j = await res.json();
      if (j?.confirmed?.length) dispatch({ type: "APPLY_CONFIRMED_DEPOSITS", confirmed: j.confirmed, ledger: j.ledger });
      else if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },

    checkDeposits: async () => {
      const res = await fetch(`${API_BASE}/api/deposits/check`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ limit: 60 })
      });
      const j = await res.json();
      if (j?.confirmed?.length) dispatch({ type: "APPLY_CONFIRMED_DEPOSITS", confirmed: j.confirmed, ledger: j.ledger });
      else if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },
    adminProcessReady: () => dispatch({ type: "ADMIN_PROCESS_READY" }),
    adminToggleWithdrawals: () => dispatch({ type: "ADMIN_TOGGLE_WITHDRAWALS" }),
    adminSetTreasuryConfig: (cfg) => dispatch({ type: "ADMIN_SET_TREASURY_CONFIG", ...cfg }),
    processWithdrawal: (id, status) => dispatch({ type: "PROCESS_WITHDRAWAL", id, status }),
    simulateDeposit: () => dispatch({ type: "SIM_DEPOSIT" }),
    claimBonusAnimal: () => dispatch({ type: "CLAIM_BONUS_ANIMAL" }),
    simulateInvite: () => dispatch({ type: "SIM_REF_INVITE" }),
    claimReferralMilestone: (k) => dispatch({ type: "CLAIM_REF_MILESTONE", k }),
    setReferrer: (code) => dispatch({ type: "SET_REFERRER", code }),
    claimTask: (taskId, scope) => dispatch({ type: "CLAIM_TASK", taskId, scope }),
    requestWithdraw: ({ wallet, coins }) => dispatch({ type: "REQUEST_WITHDRAW", wallet, coins }),
    ackUiEvent: (id) => dispatch({ type: "ACK_UI_EVENT", id }),
    claimMission: (scope, id) => dispatch({ type: "CLAIM_MISSION", scope, id }),
    advanceOnboarding: () => dispatch({ type: "ADVANCE_ONBOARDING" }),
    toggleSound: () => dispatch({ type: "TOGGLE_SOUND" }),
    claimAchievement: (id) => dispatch({ type: "CLAIM_ACHIEVEMENT", id }),
    setPlayerName: (name) => dispatch({ type: "SET_PLAYER_NAME", name }),
    buyEventPass: (priceUsd) => dispatch({ type: "BUY_EVENT_PASS", priceUsd }),
    buyEventAnimal: (id, priceVisitors) => dispatch({ type: "BUY_EVENT_ANIMAL", id, priceVisitors }),
    claimEventQuest: (id) => dispatch({ type: "CLAIM_EVENT_QUEST", id }),
    claimTrackTier: (tier, isPass) => dispatch({ type: "CLAIM_TRACK_TIER", tier, isPass }),
    claimInbox: (id) => dispatch({ type: "CLAIM_INBOX", id }),
    finishTutorial: () => dispatch({ type: "FINISH_TUTORIAL" }),
    reset: () => dispatch({ type: "RESET" }),
  }), []);

  return { state, derived, actions };
}
