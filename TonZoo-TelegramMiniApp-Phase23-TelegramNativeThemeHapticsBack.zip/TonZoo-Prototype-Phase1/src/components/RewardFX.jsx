import React, { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ANIMALS, PAVILIONS } from "../data/catalog";
import { playPop, playWin, playCelebrate } from "../utils/sound";

function uid() {
  return (crypto.randomUUID?.() || String(Math.random()));
}

const CONFETTI_COLORS = ["c1","c2","c3"]; 

function makeParticles(n = 22) {
  const arr = [];
  for (let i = 0; i < n; i++) {
    arr.push({
      c: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      id: uid(),
      x: (Math.random() * 100 - 50).toFixed(2),
      y: (-Math.random() * 60 - 20).toFixed(2),
      r: (Math.random() * 360).toFixed(0),
      d: (Math.random() * 0.6 + 0.4).toFixed(2),
      s: (Math.random() * 10 + 8).toFixed(1),
    });
  }
  return arr;
}

/**
 * Reward / celebration effects layer.
 * Reads gs.state.uiEvents and displays:
 * - floating toasts
 * - coin/visitor/ticket pop text
 * - confetti burst for "celebrate" events
 */
export default function RewardFX({ gs }) {
  const events = gs.state.uiEvents || [];

  const [confetti, setConfetti] = useState([]);

  useEffect(() => {
    const celeb = events.find((e) => e.type === "celebrate");
    if (celeb) {
      setConfetti(makeParticles(28));
      // auto clear after animation
      const t = setTimeout(() => setConfetti([]), 1200);
      return () => clearTimeout(t);
    }
  }, [events]);


// Sound effects (simple WebAudio tones)
useEffect(() => {
  if (!gs.state.soundOn) return;
  const last = events[events.length - 1];
  if (!last) return;
  if (last.type === "pop" || last.type === "icon") playPop();
  if (last.type === "toast") playPop();
  if (last.type === "achievement") playWin();
  if (last.type === "celebrate" || last.type === "summon") playCelebrate();
// eslint-disable-next-line react-hooks/exhaustive-deps
}, [events.length, gs.state.soundOn]);

  // Ack events after a short time so they don't stick
  useEffect(() => {
    if (!events.length) return;
    const ids = events.map((e) => e.id);
    const t = setTimeout(() => {
      ids.forEach((id) => gs.actions.ackUiEvent(id));
    }, 1600);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [events.length]);

  const pops = useMemo(() => events.filter((e) => e.type === "pop"), [events]);
  const icons = useMemo(() => events.filter((e) => e.type === "icon"), [events]);
  const summons = useMemo(() => events.filter((e) => e.type === "summon"), [events]);
  const achieves = useMemo(() => events.filter((e) => e.type === "achievement"), [events]);
  const toasts = useMemo(() => events.filter((e) => e.type === "toast"), [events]);

  return (
    <>
      
{/* Summon modal */}
<AnimatePresence>
  {summons.length > 0 ? (
    <motion.div className="modalOverlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.div
        className="summonCard"
        initial={{ scale: 0.92, y: 12, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.96, y: 10, opacity: 0 }}
        transition={{ type: "spring", stiffness: 320, damping: 26 }}
      >
        {(() => {
          const ev = summons[summons.length - 1];
          const item = ev.kind === "animal"
            ? ANIMALS.find(a => a.id === ev.id)
            : PAVILIONS.find(p => p.id === ev.id);
          const emoji = ev.kind === "animal" ? "🐾" : "🏟️";
          return (
            <>
              <div className="summonGlow" />
              <div className="summonEmoji">{emoji}</div>
              <div className="summonTitle">{ev.kind === "animal" ? "Animal Acquired!" : "Pavilion Built!"}</div>
              <div className="summonName">{item?.name || ev.id}</div>
              <button className="btn btnPrimary" onClick={() => gs.actions.ackUiEvent(ev.id)}>
                Awesome
              </button>
            </>
          );
        })()}
      </motion.div>
    </motion.div>
  ) : null}
</AnimatePresence>

{/* Achievement modal */}
<AnimatePresence>
  {achieves.length > 0 ? (
    <motion.div className="modalOverlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.div
        className="achCard"
        initial={{ scale: 0.92, y: 12, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.96, y: 10, opacity: 0 }}
        transition={{ type: "spring", stiffness: 320, damping: 26 }}
      >
        {(() => {
          const ev = achieves[achieves.length - 1];
          return (
            <>
              <div className="summonGlow" />
              <div className="summonEmoji">🏆</div>
              <div className="summonTitle">Achievement Unlocked</div>
              <div className="summonName">{ev.title || ev.id}</div>
              <button className="btn btnSuccess" onClick={() => gs.actions.ackUiEvent(ev.id)}>
                Claim
              </button>
            </>
          );
        })()}
      </motion.div>
    </motion.div>
  ) : null}
</AnimatePresence>

{/* Confetti burst */}
      <AnimatePresence>
        {confetti.length > 0 ? (
          <motion.div
            className="confettiLayer"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {confetti.map((p) => (
              <motion.div
                key={p.id}
                className={"confetti " + (p.c || "c1")}
                initial={{ opacity: 0, x: 0, y: 0, rotate: 0, scale: 0.8 }}
                animate={{
                  opacity: 1,
                  x: Number(p.x) * Number(p.s),
                  y: Number(p.y) * Number(p.s),
                  rotate: Number(p.r),
                  scale: Number(p.d) + 0.6,
                }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.9, ease: "easeOut" }}
              />
            ))}
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* Pop texts */}
      <div className="popLayer">
        <AnimatePresence>
          {pops.map((p) => (
            <motion.div
              key={p.id}
              className={"pop " + (p.variant || "")}
              initial={{ opacity: 0, y: 12, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -16, scale: 0.98 }}
              transition={{ duration: 0.22 }}
            >
              {p.text}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Icon fly-ups */}
      <div className="iconLayer">
        <AnimatePresence>
          {icons.map((ic) => (
            <motion.div
              key={ic.id}
              className="iconFly"
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: -26, scale: 1 }}
              exit={{ opacity: 0, y: -52, scale: 0.9 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            >
              <div className="iconEmoji">{ic.emoji || "✨"}</div>
              <div className="iconAmt">{ic.text}</div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Toast stack */}
      <div className="toastLayer">
        <AnimatePresence>
          {toasts.slice(-3).map((t) => (
            <motion.div
              key={t.id}
              className="toast"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <div className="toastTitle">{t.title}</div>
              {t.body ? <div className="toastBody">{t.body}</div> : null}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </>
  );
}
