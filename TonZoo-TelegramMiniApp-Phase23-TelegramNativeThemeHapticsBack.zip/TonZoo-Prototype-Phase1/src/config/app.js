/**
 * App configuration (Phase 5)
 * Replace these before production.
 */
export const BOT_USERNAME = "YOUR_BOT"; // e.g. "TonZooBot"
export const MINIAPP_SHORTNAME = ""; // optional, if you use @BotFather Web App short name
export const TREASURY_ADDRESS = "EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c"; // placeholder
