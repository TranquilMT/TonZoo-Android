import React from "react";
import BalancePanel from "../components/BalancePanel";
import AnimalCarousel from "./parts/AnimalCarousel";

export default function AnimalsScreen({ gs }) {
  return (
    <>
      <BalancePanel gs={gs} onExchange={gs.actions.exchangeTickets} />
      <div className="sectionHeader">
        <h3 style={{ marginTop: 0 }}>Animals</h3>
        <div className="muted tiny">Animals bring visitors each day.</div>
      </div>
      <AnimalCarousel gs={gs} />
    </>
  );
}
