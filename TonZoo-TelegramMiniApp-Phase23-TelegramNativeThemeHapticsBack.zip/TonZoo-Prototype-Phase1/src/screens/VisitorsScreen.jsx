import React from "react";
import BalancePanel from "../components/BalancePanel";
import Card from "../components/Card";

export default function VisitorsScreen({ gs }) {
  const v = Math.floor(gs.state.visitors);
  const vpd = gs.derived.visitorsPerDay;

  return (
    <>
      <BalancePanel gs={gs} onExchange={gs.actions.exchangeTickets} />

      <div className="sectionHeader">
        <h3 style={{ marginTop: 0 }}>Visitors</h3>
        <div className="muted tiny">Visitors are required to withdraw.</div>
      </div>

      <Card className="bigCard">
        <div className="row">
          <div>
            <div className="label">Current visitors</div>
            <div className="bigNum">{v.toLocaleString()} 👥</div>
          </div>
          <div className="pill blue">{vpd.toLocaleString()} / day</div>
        </div>

        <div className="hr" />

        <div className="callout">
          <div><b>Withdraw rule:</b> need ≥ 1000 visitors and ≥ 1000 withdraw coins ($1).</div>
          <div className="muted tiny">
            Top ups give visitors bonus, but withdraw coins must be earned from exchanging tickets.
          </div>
        </div>
      </Card>
    </>
  );
}
