import React from "react";
import BalancePanel from "../components/BalancePanel";
import PavilionCarousel from "./parts/PavilionCarousel";

export default function ZooScreen({ gs }) {
  return (
    <>
      <BalancePanel gs={gs} onExchange={gs.actions.exchangeTickets} />
      <div className="sectionHeader">
        <h3 style={{ marginTop: 0 }}>My Zoo</h3>
        <div className="muted tiny">Buy pavilions to generate tickets.</div>
      </div>
      <PavilionCarousel gs={gs} />
    </>
  );
}
