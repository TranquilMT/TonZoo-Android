import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import Card from "../../components/Card";
import MotionCarousel from "../../components/MotionCarousel.jsx";
import { ANIMALS } from "../../data/catalog";

export default function AnimalCarousel({ gs }) {
  const s = gs.state;

  return (
    <MotionCarousel
      items={ANIMALS}
      renderItem={(a) => {
        const owned = s.ownedAnimals[a.id] || 0;

        const isDepositOnly = !!a.depositOnly;
        const unlockedByDeposit = !!s.hasDeposited;

        const canClaimBonus = isDepositOnly && unlockedByDeposit && !s.bonusAnimalClaimed && owned === 0;
        const locked = isDepositOnly && !unlockedByDeposit && owned === 0;
        const canBuy = !locked && !isDepositOnly && a.priceVisitors != null && s.visitors >= a.priceVisitors;

        return (
          <Card className={"carouselCard " + rarityTheme(a.rarity)}>
            <AnimatePresence>
              {gs.state.lastBought?.kind === "animal" && gs.state.lastBought?.id === a.id && (Date.now() - (gs.state.lastBought?.at||0) < 2200) ? (
                <motion.div className="hatchBurst"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.1 }}
                  transition={{ duration: 0.25 }}
                >
                  <motion.div className="hatchRing" animate={{ rotate: 360 }} transition={{ duration: 1.1, repeat: 1, ease: "linear" }} />
                  <motion.div className="hatchSpark" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: -10 }} transition={{ duration: 0.5 }}>
                    ✨ New!
                  </motion.div>
                </motion.div>
              ) : null}
            </AnimatePresence>
            <div className="row" style={{ justifyContent: "space-between" }}>
              <div>
                <div className="cardTitle">{a.name}</div>
                <div className="muted tiny">{a.rarity} • Works {a.workDays} days</div>
              </div>

              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                <div className="pill">Owned: {owned}</div>
                {isDepositOnly ? <div className="pill pink">Deposit</div> : null}
              </div>
            </div>

            <div className="row twoCol" style={{ marginTop: 10 }}>
              <div>
                <div className="label">Visitors</div>
                <div className="pill blue">{a.visitorsPerDay} / day 👥</div>
              </div>
              <div>
                <div className="label">Total</div>
                <div className="pill blue">{(a.visitorsPerDay * a.workDays).toLocaleString()} 👥</div>
              </div>
            </div>

            <div className="hr" />

            {isDepositOnly ? (
              locked ? (
                <button className="btn btnLocked" disabled>Deposit-only (locked)</button>
              ) : canClaimBonus ? (
                <button className="btn btnSuccess" onClick={gs.actions.claimBonusAnimal}>Claim (deposit bonus)</button>
              ) : (
                <button className="btn btnDisabled" disabled>Claimed</button>
              )
            ) : (
              <button
                className={"btn " + (canBuy ? "btnDanger" : "btnDisabled") + (((gs.state.onboarding?.step||0)===1 && owned===0) ? " pulseRing" : "")}
                disabled={!canBuy}
                onClick={() => gs.actions.buyAnimal(a.id)}
              >
                Buy for {a.priceVisitors?.toLocaleString()} 👥
              </button>
            )}
          </Card>
        );
      }}
    />
  );
}

function rarityTheme(r) {
  if (r === "Exclusive") return "exclusive";
  if (r === "Special") return "special";
  return "normal";
}
