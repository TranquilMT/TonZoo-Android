import React, { useState } from "react";
import AchievementsPanel from "../components/AchievementsPanel.jsx";
import AdminPanel from "../components/AdminPanel.jsx";
import DepositModal from "../components/DepositModal.jsx";
import Card from "../components/Card";
import { TonConnectButton, useTonConnectUI, useTonWallet } from "@tonconnect/ui-react";
import { TREASURY_ADDRESS } from "../config/app.js";

export default function ProfileScreen({ gs }) {
  const [adminOpen, setAdminOpen] = useState(false);
  const [depOpen, setDepOpen] = useState(false);
  const [pin, setPin] = useState("");
  const [achOpen, setAchOpen] = useState(false);
  return (
    <div className="screen">
      <Card className="bigCard">
        <div className="row" style={{ alignItems: "flex-start" }}>
          <div>
            <h3 style={{ margin: 0 }}>Profile</h3>
            <div className="muted tiny">TonZoo Player • Prototype build</div>
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <TonConnectButton />
          </div>
        </div>

        <div className="hr" />

        <div className="row">
          <button className={"btn " + (gs.state.soundOn ? "btnPrimary" : "btnDisabled")} onClick={gs.actions.toggleSound} style={{ padding: "10px 12px" }}>
            {gs.state.soundOn ? "🔊 Sound" : "🔇 Muted"}
          </button>
          <button className="btn btnPrimary" onClick={() => setAchOpen(true)} style={{ padding: "10px 12px" }}>
            🏆 Achievements
          </button>
          <button className="btn btnDanger" onClick={() => setAdminOpen(true)} style={{ padding: "10px 12px" }}>
            🛠 Admin
          </button>
          <button className="btn btnPrimary" onClick={() => setDepOpen(true)} style={{ padding: "10px 12px" }}>
            💳 Deposit
          </button>
          <button
          </button>
          <button className="btn btnDisabled"
          </button>
          <div className="pill blue">Deposit status: {gs.state.hasDeposited ? "Confirmed" : "Not yet"}</div>
          <div className="pill">Rare vouchers: {gs.state.rareAnimalVouchers || 0}</div>
        </div>
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>TON Deposit</h3>
        <div className="muted tiny">
          This is <b>frontend scaffolding</b>. For production, you must verify deposits server-side before crediting users.
        </div>

        <div className="hr" />

        <TonDepositBlock gs={gs} />
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Deposit history</h3>
        <div className="muted tiny">Pending → Confirmed (simulate confirm for now).</div>

        <div className="hr" />

        {(!gs.state.deposits || gs.state.deposits.length === 0) ? (
          <div className="muted">No deposits yet.</div>
        ) : (
          <div className="list">
            {gs.state.deposits.slice().reverse().map((d) => (
              <div className="listItem" key={d.id} style={{ alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <b>{d.amountTon} TON</b>
                  <div className="muted tiny">To: {d.treasury}</div>
                  <div className="muted tiny">
                    Status: <b>{d.status}</b>
                    {d.createdAt ? <> • {new Date(d.createdAt).toLocaleString()}</> : null}
                  </div>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
                  <div className={"pill " + (d.status === "Confirmed" ? "green" : "")}>{d.status}</div>
                  {d.status !== "Confirmed" ? (
                    <button
                      className="btn btnSuccess"
                      onClick={() => gs.actions.confirmDeposit(d.id)}
                      style={{ padding: "10px 12px" }}
                    >
                      Simulate confirm
                    </button>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Withdrawal queue</h3>
        <div className="muted tiny">Requests are queued (server) and processed after the delay.</div>

        <div className="hr" />

        {(!gs.state.withdrawals || gs.state.withdrawals.length === 0) ? (
          <div className="muted">No withdrawal requests.</div>
        ) : (
          <div className="list">
            {gs.state.withdrawals.slice().reverse().map((w) => (
              <div className="listItem" key={w.id} style={{ alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <b>${w.usd} • {w.coins} withdraw coins</b>
                  <div className="muted tiny">Wallet: {w.wallet}</div>
                  <div className="muted tiny">Currency: <b>{w.currency || "TON"}</b> • Net: <b>${(w.netUsd ?? (w.usd*(1-(w.feePct||0.05)))).toFixed ? (w.netUsd ?? (w.usd*(1-(w.feePct||0.05)))).toFixed(2) : (w.netUsd ?? "")} </b></div>
                  {w.processAfter ? <div className="muted tiny">Process after: {new Date(w.processAfter).toLocaleString()}</div> : null}
                  <div className="muted tiny">Status: <b>{w.status}</b></div>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
                  <div className={"pill " + (w.status === "Paid" ? "green" : w.status === "Rejected" ? "pink" : "")}>
                    {w.status}
                  </div>
                  {w.status === "Pending" ? (
                    <>
                      <button
                        className="btn btnSuccess"
                        onClick={() => gs.actions.processWithdrawal(w.id, "Paid")}
                        style={{ padding: "10px 12px" }}
                      >
                        Mark paid
                      </button>
                      <button
                        className="btn btnDanger"
                        onClick={() => gs.actions.processWithdrawal(w.id, "Rejected")}
                        style={{ padding: "10px 12px" }}
                      >
                        Reject
                      </button>
                    </>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Help</h3>
        <div className="grid2">
          <button className="btn btnPrimary" disabled>Community chat</button>
          <button className="btn btnPrimary" disabled>News channel</button>
          <button className="btn btnSuccess" disabled>Support</button>
          <button className="btn btnPrimary" disabled>License Agreement</button>
        </div>
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Dev tools</h3>
        <button className="btn btnDanger" onClick={gs.actions.reset}>Reset save</button>
      </Card>
    </div>
  );
}

function TonDepositBlock({ gs }) {
  const wallet = useTonWallet();
  const [tonConnectUI] = useTonConnectUI();
  const [amount, setAmount] = useState("0.5");
  const [usd, setUsd] = useState("1");
  const [busy, setBusy] = useState(false);
  const connected = !!wallet?.account?.address;

  const TREASURY = TREASURY_ADDRESS;
  const canSend = connected && !busy && Number(amount) > 0;

  const onSend = async () => {
    if (!canSend) return;
    setBusy(true);
    try {
      const nano = BigInt(Math.floor(Number(amount) * 1e9)).toString();

      await tonConnectUI.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 360,
        messages: [{ address: TREASURY, amount: nano }],
      });

      gs.actions.recordDeposit({ amountTon: Number(amount), usd: Number(usd), treasury: TREASURY });
    } catch (e) {
      console.warn(e);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <div className="grid2" style={{ gap: 10 }}>
        <label className="field">
          <span>Amount (TON)</span>
          <input value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" placeholder="0.5" />
        </label>
        <label className="field">
          <span>Amount (USD)</span>
          <input value={usd} onChange={(e) => setUsd(e.target.value)} inputMode="decimal" placeholder="1" />
        </label>
      </div>

      <button
        className={"btn " + (canSend ? "btnPrimary" : "btnDisabled")}
        disabled={!canSend}
        onClick={onSend}
        style={{ width: "100%", marginTop: 10 }}
      >
        {busy ? "Sending..." : connected ? "Send TON Deposit" : "Connect wallet to deposit"}
      </button>

      <div className="muted tiny" style={{ marginTop: 8 }}>
        Tip: for now you can also use the <b>Top up</b> modal (simulated) to test economy quickly.
      </div>
    </div>
  );
}
