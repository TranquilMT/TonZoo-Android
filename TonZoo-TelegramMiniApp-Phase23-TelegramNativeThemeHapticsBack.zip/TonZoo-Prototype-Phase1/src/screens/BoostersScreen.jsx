import React from "react";
import Card from "../components/Card";
import { BOOSTERS } from "../data/boosters";

function costText(cost) {
  if (!cost) return "Free";
  if (cost.coinsPurchase) return `${cost.coinsPurchase} 🟩`;
  return "—";
}

function activeText(b, now, activeBoosters) {
  if (b.effect?.freeWheelSpins) return null;
  const active = (activeBoosters || []).find((x) => x.id === b.id && (!x.expiresAt || now <= x.expiresAt));
  if (!active) return null;
  const leftMs = Math.max(0, active.expiresAt - now);
  const mins = Math.ceil(leftMs / 60000);
  return `Active • ${mins} min left`;
}

export default function BoostersScreen({ gs }) {
  const s = gs.state;
  const now = Date.now();

  return (
    <div className="stack">
      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Boosters</h3>
        <div className="muted tiny">
          Boosters cost <b>Coins for purchases</b>.
        </div>

        <div className="hr" />

        <div className="list">
          {BOOSTERS.map((b) => {
            const cost = b.cost?.coinsPurchase || 0;
            const canBuy = s.coinsPurchase >= cost;
            const active = activeText(b, now, s.activeBoosters);

            return (
              <div className="listItem" key={b.id} style={{ alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <b>{b.title}</b>
                  <div className="muted tiny">{b.desc}</div>
                  <div className="muted tiny" style={{ marginTop: 6 }}>
                    Cost: <b>{costText(b.cost)}</b>
                    {active ? <span> • <b>{active}</b></span> : null}
                  </div>
                </div>

                <button
                  className={"btn " + (canBuy ? "btnPrimary" : "btnDisabled")}
                  disabled={!canBuy}
                  onClick={() => gs.actions.buyBooster(b.id)}
                  style={{ padding: "10px 12px", width: 110 }}
                >
                  Buy
                </button>
              </div>
            );
          })}
        </div>
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Active</h3>
        <div className="callout">
          <div><b>Free Wheel spins:</b> {s.freeWheelSpins || 0}</div>
          <div className="muted tiny" style={{ marginTop: 6 }}>
            Timed boosters appear above with remaining time.
          </div>
        </div>
      </Card>
    </div>
  );
}
