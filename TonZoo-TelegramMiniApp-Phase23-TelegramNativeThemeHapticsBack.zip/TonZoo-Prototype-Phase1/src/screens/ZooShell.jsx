import React, { useState } from "react";
import ZooScreen from "./ZooScreen";
import AnimalsScreen from "./AnimalsScreen";
import VisitorsScreen from "./VisitorsScreen";

export default function ZooShell({ gs, initialSub }) {
  const [sub, setSub] = useState(initialSub || "zoo");

  const forceAnimals = (gs.state.onboarding?.step || 0) === 1;
  const active = forceAnimals ? "animals" : sub;

  return (
    <div className="screen">
      <div className="segTabs">
        <button className={"segBtn " + (active === "zoo" ? "active" : "")} onClick={() => setSub("zoo")}>
          Zoo
        </button>
        <button className={"segBtn " + (active === "animals" ? "active" : "") + (forceAnimals ? " pulseRing" : "")} onClick={() => setSub("animals")}>
          Animals
        </button>
        <button className={"segBtn " + (active === "visitors" ? "active" : "")} onClick={() => setSub("visitors")}>
          Visitors
        </button>
      </div>

      {active === "zoo" && <ZooScreen gs={gs} />}
      {active === "animals" && <AnimalsScreen gs={gs} />}
      {active === "visitors" && <VisitorsScreen gs={gs} />}
    </div>
  );
}
