# TonZoo Prototype (Phase 1)

## Install & Run
1) Install Node.js (LTS).
2) In this folder:
   - `npm install`
   - `npm run dev`

Open the URL printed in the terminal.

## Notes
- Top up is simulated (adds Coins for purchases + visitors bonus).
- Withdraw coins come ONLY from exchanging tickets.
- Withdrawal requests are stored locally as "Pending".
- Progress saves to localStorage.


## Run as a Telegram Mini App (TWA)
1) Deploy this project to HTTPS hosting (Vercel/Netlify/Cloudflare Pages).
2) In BotFather:
   - Set **Menu Button** URL to your deployed site (or set a Web App button).
3) Open your bot in Telegram → tap the menu button → TonZoo opens.

### Local testing
You can run locally with `npm run dev`, but Telegram requires HTTPS for real embedding.


## Phase 2 additions
- Tasks (Daily + One-time)
- Boosters (timed multipliers + free wheel spin)


## Phase 2.5 additions
- Auction mini-game (simulated competitors, visitor bids, 80% refund on loss)


## Phase 4 additions
- Telegram start parameter parsing (tgWebAppStartParam / initDataUnsafe.start_param)
- Referral deep link format using startapp=ref_CODE
- TON Connect scaffolding (@tonconnect/ui-react) + connect button + sendTransaction deposit stub


## Phase 5 additions
- App config (bot username, miniapp shortname, treasury)
- Referral invite link uses startapp=ref_CODE with optional /shortname
- Deposit receipt model (Pending/Confirmed) + simulate confirm
- Withdrawal queue admin simulation (mark paid/reject)


## Polish pass
- Fixed missing imports in Friends screen
- Rebuilt Profile screen UI (TonConnect + deposit/withdraw panels)
- Added small UI transitions + safe-area padding


## UI consistency pass
- Unified card padding/radius, pills, list items, segmented tabs, button styling
- Improved Games/Auction/Tasks/Boosters layouts
- Enhanced Animals deposit-only badge


## Phase 6
- Swipe indicators for carousels
- First-run tutorial overlay


## Phase 7
- Framer Motion spring swipe carousel (Animals + Pavilions)
- Active-card scaling + snap + smoother gestures


## Reward FX
- Floating reward pops for buys/wins
- Toast notifications for claims/requests
- Confetti burst for jackpots/auction wins/milestones/deposit confirm


## Phase 9
- Multi-color confetti (cyan/purple/pink)
- Icon fly-ups for tickets/visitors/coins rewards


## Withdrawal gate
- Withdrawals require at least $1 total deposits (prototype). Enforced via depositUsdTotal >= 1.


## Onboarding
- Starting visitors set to first animal cost (180) so players can buy one animal immediately.
- Animated intro story replaces tutorial overlay.


## Cinematic intro
- 2.4s logo reveal then animated onboarding steps
- Tap highlights guide users to key tabs


## Guided first purchase
- After intro, Zoo opens directly on Animals.
- Animals tab + first buy button pulse until first animal is bought.


## Phase 11 (Cool upgrades)
- Summon animation modal when buying animals/pavilions
- Achievement unlock modal (first animal/pavilion/mission + big win)
- Lightweight SFX using WebAudio (toggle in Profile)


## Phase 12 (Wow pack)
- In-card hatch burst animation after purchases
- Achievements panel (Profile) with claimable rewards
- Global button press feel (CSS) + click SFX + light haptics


## Phase 13 (Live events)
- Events tab with limited-time animal + countdown
- Event Pass (+10% tickets) gated by total deposits
- Weekly local leaderboard (prototype) with weekly UTC reset


## Phase 14 (Events expansion)
- Rewards Track (tiers) with free + pass rewards
- Event Quests (daily) that grant event points
- Weekly leaderboard prizes delivered to Inbox on reset


## Phase 15B (B2 Auto-Verify Deposits)
- Added /server express app for on-chain verification (TON + USDT prototype)
- Frontend Deposit modal creates deposit intent + shows required comment
- "Check Deposits" polls server and credits coins + treasury split when confirmed

### Run server
```bash
cd server
cp .env.example .env
npm install
npm run dev
```

### Run frontend
```bash
npm install
npm run dev
```


## Phase 16 (Phase C: Withdrawals server queue + user currency)
- Withdrawal requests go to server (TON or USDT choice)
- Server processes withdrawals after delay and deducts only from Treasury ledger
- Frontend syncs server ledger and updates local withdrawal statuses


## Phase 17 (Demo Wallet)
- Added Demo Pay button in Deposit modal to instantly confirm a deposit intent (no blockchain)
- Server endpoint `/api/demo/confirm` for demo/testing only


## Phase 18 (Demo wallet UI + optional real TonConnect)
- Deposit modal has Wallet Mode: Demo Wallet or Real TonConnect
- Demo Wallet shows a fake approval popup and confirms deposit instantly
- Real TonConnect uses TonConnectButton + sendTransaction for TON deposits
- USDT via TonConnect is marked as next phase (use Demo for USDT deposits)


## Phase 20 (Bulletproof deposit confirmation)
- Server runs an auto-poller to scan and confirm pending deposits (POLL_INTERVAL_MS)
- Client auto-checks deposits after TonConnect payments (TON + USDT)
- Greatly reduces cases where users have to manually spam "Check Deposits"


## Phase 21 (Server receipt store persistence)
- Server persists ledger + deposits + withdrawals to `DB_FILE` (default: server/tonzoo_db.json)
- Prevents losing confirmations if client reloads or server restarts


## Phase 22 (Icons + Telegram mobile polish)
- Added favicon + Apple touch icon + PWA manifest
- Added app icons (192/512) and updated TonConnect iconUrl
- Improved mobile touch behavior (no overscroll, tap highlight off, safe-area/viewport-fit)


## Phase 23 (Telegram native feel)
- Telegram WebApp theme sync (colors update live)
- Telegram HapticFeedback on key events
- Telegram BackButton closes open modals
